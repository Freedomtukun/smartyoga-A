# SmartYoga Canada MVP

Local-first yoga posture coaching platform for the Canadian market. The monorepo contains the React Native mobile client, FastAPI backend, MediaPipe pose microservice, and Piper-based TTS service.

## Getting Started

```bash
cp .env.sample .env
make deps        # optional helper script to install deps
make compose-up  # or docker compose up --build
```

Services:
- `apps/mobile` – React Native 0.74 (Expo) client showing Score + Advice + Summary.
- `services/api` – FastAPI gateway with Stripe billing and session storage.
- `services/pose` – MediaPipe Tasks pose inference microservice.
- `services/tts` – Piper local TTS with Coqui fallback adapter.
- `services/signaling` – WebRTC signaling + room orchestration.

### Environment Keys

### MCP Manifest

- `config/mcp/smartyoga.mcp.json` exposes OpenAPI + Commerce endpoints for ChatGPT MCP clients.

- Set `OPENAI_API_KEY` in your `.env` (and secret manager in deployment) to enable GPT-Realtime-Mini + Audio-Mini。
- Optional: set `AI_BACKEND=openai` to force OpenAI Realtime, or leave `auto` to fall back to Grok when unavailable.
- Provide `FRONTEND_BASE_URL` for commerce callbacks and Stripe success/cancel redirects.
- Override `OPENAI_REALTIME_MODEL` if you need a different realtime-capable model.
- Optionally override `OPENAI_BASE_URL` if you proxy OpenAI traffic.
- Quick health check:
  ```bash
  source .env
  curl -s -o /dev/null -w "%{http_code}\n" https://api.openai.com/v1/models \
    -H "Authorization: Bearer $OPENAI_API_KEY"
  # expect 200
  ```

Documentation lives in `docs/` with architecture, compliance, and API contracts. See `docs/api.md` for the latest OpenAPI reference.

- Guardrails: Lightweight blocklist applied to all assistant replies before streaming.
