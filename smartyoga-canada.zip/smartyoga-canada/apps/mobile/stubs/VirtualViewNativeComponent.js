// Expo Go for SDK 54 ships without the new VirtualView native component that
// React Native 0.81 references. We alias the module to the existing View
// native component so Metro can bundle without crashing.
const rnModule = require('react-native/Libraries/Components/View/ViewNativeComponent');
const ViewNativeComponent =
  (rnModule && rnModule.default) || rnModule || (() => null);

module.exports = ViewNativeComponent;
module.exports.default = ViewNativeComponent;
module.exports.Commands = rnModule?.Commands || {};
