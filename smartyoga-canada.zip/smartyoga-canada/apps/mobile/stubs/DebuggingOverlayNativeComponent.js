// Stub for DebuggingOverlay native component on Expo Go (SDK 54) where the
// actual native module is not available yet. We reuse the base View native
// component so the rest of React Native can mount it safely, and expose noop
// command methods to mirror the real API.
const rnModule = require('react-native/Libraries/Components/View/ViewNativeComponent');
const ViewNativeComponent =
  (rnModule && rnModule.default) || rnModule || (() => null);

const Commands = {
  highlightTraceUpdates: () => {},
  highlightElements: () => {},
  clearElementsHighlights: () => {},
};

module.exports = ViewNativeComponent;
module.exports.default = ViewNativeComponent;
module.exports.Commands = Commands;
