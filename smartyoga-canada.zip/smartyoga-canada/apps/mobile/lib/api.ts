export const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL!;

export type PoseLandmark = {
  x: number;
  y: number;
  z?: number;
  conf?: number;
  score?: number;
};

export type PoseScoreData = {
  score: number;
  advice: string;
  summary: string;
  metrics?: Record<string, number | string | boolean>;
  landmarks?: PoseLandmark[];
};

export type PoseScoreResponse = {
  ok: boolean;
  data?: PoseScoreData;
  error?: string;
};

export async function scoreImage({
  dataUri,
  userId = "u1",
  poseId = "generic",
  apiKey,
  includeLandmarks,
}: {
  dataUri: string;
  userId?: string;
  poseId?: string;
  apiKey?: string;
  includeLandmarks?: boolean;
}): Promise<PoseScoreResponse> {
  const search =
    typeof includeLandmarks === "boolean"
      ? `?includeLandmarks=${includeLandmarks ? "1" : "0"}`
      : "";

  const res = await fetch(`${API_BASE}/pose/score${search}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(apiKey ? { "x-api-key": apiKey } : {}),
    },
    body: JSON.stringify({
      userId,
      poseId,
      image_base64: dataUri,
      includeLandmarks,
    }),
  });
  return res.json();
}
