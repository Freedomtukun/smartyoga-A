const { getDefaultConfig } = require('expo/metro-config');
const { resolve } = require('metro-resolver');
const path = require('path');

const projectRoot = __dirname;
const config = getDefaultConfig(projectRoot);

const stubEntries = {
  VirtualViewNativeComponent: path.join(
    projectRoot,
    'stubs',
    'VirtualViewNativeComponent.js',
  ),
  DebuggingOverlayNativeComponent: path.join(
    projectRoot,
    'stubs',
    'DebuggingOverlayNativeComponent.js',
  ),
};

const baseResolver = config.resolver || {};
const fallbackResolve = baseResolver.resolveRequest
  ? baseResolver.resolveRequest.bind(baseResolver)
  : resolve;

function normalizeModuleName(name) {
  return name.replace(/\\/g, '/').replace(/\.js$/g, '');
}

config.resolver = {
  ...baseResolver,
  resolveRequest(context, moduleName, platform) {
    const normalized = normalizeModuleName(moduleName);

    for (const [key, stubPath] of Object.entries(stubEntries)) {
      if (
        normalized === key ||
        normalized.endsWith(`/${key}`) ||
        normalized.endsWith(key)
      ) {
        return {
          type: 'sourceFile',
          filePath: stubPath,
        };
      }
    }

    return fallbackResolve(context, moduleName, platform);
  },
};

module.exports = config;
