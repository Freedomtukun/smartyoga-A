import { useEffect, useMemo, useRef, useState } from "react";

type PeerInfo = {
  peerId: string;
  lastSeen: number;
};

const HEARTBEAT_INTERVAL = 25_000;

function buildSignalingUrl() {
  const explicit = process.env.EXPO_PUBLIC_SIGNALING_URL;
  if (explicit) return explicit;
  // derive from API base (http -> ws)
  const base = (process.env.EXPO_PUBLIC_API_BASE_URL || "").replace(/\/$/, "");
  if (!base) return "";
  return base.replace(/^http/, "ws") + "/signal";
}

function randomPeerId() {
  return `peer_${Math.random().toString(16).slice(2, 10)}`;
}

export function useSignaling(enabled: boolean, roomId: string) {
  const [connected, setConnected] = useState(false);
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [peerId] = useState(() => randomPeerId());
  const [error, setError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const signalingUrl = useMemo(() => buildSignalingUrl(), []);

  useEffect(() => {
    if (!enabled || !signalingUrl) {
      setConnected(false);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      return;
    }

    const socket = new WebSocket(signalingUrl);
    wsRef.current = socket;

    socket.onopen = () => {
      setConnected(true);
      setError(null);
      socket.send(JSON.stringify({ type: "join", roomId, peerId }));
      heartbeatRef.current = setInterval(() => {
        socket.send(JSON.stringify({ type: "ping", ts: Date.now() }));
      }, HEARTBEAT_INTERVAL);
    };

    socket.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        switch (payload.type) {
          case "joined":
            setPeers(() =>
              (payload.peers || []).map((item: any) => ({
                peerId: item.peerId,
                lastSeen: Date.now(),
              })),
            );
            break;
          case "peer.joined":
            setPeers((prev) => [
              { peerId: payload.peerId, lastSeen: Date.now() },
              ...prev.filter((p) => p.peerId !== payload.peerId),
            ]);
            break;
          case "peer.left":
            setPeers((prev) => prev.filter((p) => p.peerId !== payload.peerId));
            break;
          case "signal":
            setPeers((prev) =>
              prev.map((p) =>
                p.peerId === payload.fromPeerId ? { ...p, lastSeen: Date.now() } : p,
              ),
            );
            break;
          case "error":
            setError(payload.detail || payload.code || "signal_error");
            break;
          default:
            break;
        }
      } catch (err) {
        console.warn("signaling message parse failed", err);
      }
    };

    socket.onerror = (evt) => {
      console.error("signaling error", evt);
      setError("signal_socket_error");
    };

    socket.onclose = () => {
      setConnected(false);
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
        heartbeatRef.current = null;
      }
    };

    return () => {
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
        heartbeatRef.current = null;
      }
      socket.close();
      wsRef.current = null;
    };
  }, [enabled, peerId, roomId, signalingUrl]);

  const sendSignal = (targetPeerId: string, data: unknown) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({ type: "signal", targetPeerId, data, roomId, peerId }),
    );
  };

  return {
    peerId,
    peers,
    connected,
    error,
    sendSignal,
  };
}

