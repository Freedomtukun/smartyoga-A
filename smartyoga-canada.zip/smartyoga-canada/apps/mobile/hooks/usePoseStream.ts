import { useEffect, useMemo, useRef, useState } from "react";
import { fetchEventSource } from "@microsoft/fetch-event-source";
import { API_BASE } from "../lib/api";

export type PoseStreamEvent = {
  ts: number;
  frame: string | null;
  poses: Array<{
    track_id?: number;
    tracking_id?: number;
    pose_id?: number;
    confidence?: number;
  }>;
  meta?: Record<string, unknown>;
};

const DEFAULT_EVENT_LIMIT = 10;

function buildPoseStreamUrl() {
  const explicit = process.env.EXPO_PUBLIC_POSE_STREAM_URL;
  if (explicit) return explicit;
  const base = API_BASE.replace(/\/$/, "");
  return `${base}/events/pose/stream`;
}

export function usePoseStream(enabled: boolean, limit = DEFAULT_EVENT_LIMIT) {
  const [events, setEvents] = useState<PoseStreamEvent[]>([]);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const controllerRef = useRef<AbortController | null>(null);

  const streamUrl = useMemo(() => buildPoseStreamUrl(), []);

  useEffect(() => {
    if (!enabled) {
      if (controllerRef.current) {
        controllerRef.current.abort();
        controllerRef.current = null;
      }
      setConnected(false);
      return;
    }

    const controller = new AbortController();
    controllerRef.current = controller;

    fetchEventSource(streamUrl, {
      signal: controller.signal,
      async onopen(response) {
        if (response.ok) {
          setConnected(true);
          setError(null);
        } else {
          setError(`HTTP ${response.status}`);
        }
      },
      onmessage(evt) {
        if (!evt.data) return;
        try {
          const parsed = JSON.parse(evt.data);
          const event: PoseStreamEvent = {
            ts: parsed?.ts ?? Date.now(),
            frame: parsed?.frame ?? null,
            poses: parsed?.poses ?? [],
            meta: parsed?.meta ?? {},
          };
          setEvents((prev) => {
            const next = [event, ...prev];
            return next.slice(0, limit);
          });
        } catch (err) {
          console.warn("Failed to parse pose event", err);
        }
      },
      onerror(err) {
        console.error("Pose stream error", err);
        setError(err?.message || "stream_error");
        setConnected(false);
        throw err;
      },
    }).catch((err) => {
      if (controller.signal.aborted) return;
      console.error("Pose stream aborted", err);
      setError(err?.message || "stream_error");
      setConnected(false);
    });

    return () => {
      controller.abort();
      controllerRef.current = null;
      setConnected(false);
    };
  }, [enabled, limit, streamUrl]);

  return { events, connected, error };
}

