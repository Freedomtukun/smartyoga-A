import React from "react";
import { StyleSheet } from "react-native";
import Svg, { Circle, Defs, LinearGradient, Line, Stop } from "react-native-svg";
import type { PoseLandmark } from "../lib/api";

const CONNECTIONS: Array<[number, number]> = [
  [11, 12],
  [11, 13],
  [13, 15],
  [12, 14],
  [14, 16],
  [15, 17],
  [16, 18],
  [11, 23],
  [12, 24],
  [23, 24],
  [23, 25],
  [25, 27],
  [27, 29],
  [24, 26],
  [26, 28],
  [28, 30],
  [23, 27],
  [24, 28],
];

const MIN_CONFIDENCE = 0.25;

function getCoord(point: PoseLandmark | undefined, size: { width: number; height: number }) {
  if (!point) return null;
  const conf = point.conf ?? point.score ?? 1;
  if (conf < MIN_CONFIDENCE) return null;
  return {
    x: point.x * size.width,
    y: point.y * size.height,
    conf,
  };
}

export type PoseOverlayProps = {
  landmarks: PoseLandmark[];
  width: number;
  height: number;
  color?: string;
  jointColor?: string;
};

export default function PoseOverlay({
  landmarks,
  width,
  height,
  color = "#6366F1",
  jointColor = "#EEF2FF",
}: PoseOverlayProps) {
  if (!width || !height) return null;

  const size = { width, height };

  return (
    <Svg width={width} height={height} style={styles.svg}>
      <Defs>
        <LinearGradient id="poseGradient" x1="0" x2="0" y1="0" y2="1">
          <Stop offset="0%" stopColor={color} stopOpacity={0.95} />
          <Stop offset="100%" stopColor={color} stopOpacity={0.65} />
        </LinearGradient>
      </Defs>

      {CONNECTIONS.map(([i, j]) => {
        const a = getCoord(landmarks[i], size);
        const b = getCoord(landmarks[j], size);
        if (!a || !b) return null;
        return (
          <Line
            key={`${i}-${j}`}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke="url(#poseGradient)"
            strokeWidth={4}
            strokeLinecap="round"
            opacity={0.9}
          />
        );
      })}

      {landmarks.map((pt, idx) => {
        const coord = getCoord(pt, size);
        if (!coord) return null;
        return (
          <Circle
            key={idx}
            cx={coord.x}
            cy={coord.y}
            r={4.5}
            fill={jointColor}
            stroke={color}
            strokeWidth={1.5}
            opacity={0.9}
          />
        );
      })}
    </Svg>
  );
}

const styles = StyleSheet.create({
  svg: {
    ...StyleSheet.absoluteFillObject,
  },
});
