import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  LayoutChangeEvent,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import * as ImageManipulator from "expo-image-manipulator";
import * as ImagePicker from "expo-image-picker";
import PoseOverlay from "./PoseOverlay";
import { API_BASE, PoseScoreData, scoreImage } from "../lib/api";
import { usePoseStream } from "../hooks/usePoseStream";
import { useSignaling } from "../hooks/useSignaling";

const METRIC_LABELS: Record<string, string> = {
  symmetry: "Symmetry",
  verticality: "Verticality",
  extension: "Extension",
  confidence: "Confidence",
};

function defaultPoseStreamUrl() {
  return process.env.EXPO_PUBLIC_POSE_STREAM_URL ?? `${API_BASE.replace(/\/$/, "")}/events/pose/stream`;
}

function defaultSignalingUrl() {
  const explicit = process.env.EXPO_PUBLIC_SIGNALING_URL;
  if (explicit) return explicit;
  const base = API_BASE.replace(/\/$/, "");
  return base.replace(/^http/, "ws") + "/signal";
}

export default function SmartYogaCamera() {
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [overlayLoading, setOverlayLoading] = useState(false);
  const [result, setResult] = useState<PoseScoreData | null>(null);
  const [showSkeleton, setShowSkeleton] = useState(true);
  const [watchRealtime, setWatchRealtime] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [lastDataUri, setLastDataUri] = useState<string | null>(null);
  const [skeletonError, setSkeletonError] = useState(false);

  const poseStreamUrl = useMemo(defaultPoseStreamUrl, []);
  const signalingUrl = useMemo(defaultSignalingUrl, []);

  const poseStream = usePoseStream(watchRealtime);
  const signaling = useSignaling(watchRealtime, "coach-lab");
  const latestPoseEvent = poseStream.events[0];

  async function ensurePerms(kind: "camera" | "library") {
    if (kind === "camera") {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== "granted") throw new Error("Camera permission denied");
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") throw new Error("Library permission denied");
    }
  }

  const onImageLayout = useCallback((event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setCanvasSize({ width, height });
  }, []);

  async function pick(kind: "camera" | "library") {
    try {
      setResult(null);
      setLoading(true);
      setOverlayLoading(false);
      setSkeletonError(false);
      await ensurePerms(kind);

      const picker =
        kind === "camera"
          ? await ImagePicker.launchCameraAsync({ quality: 0.9 })
          : await ImagePicker.launchImageLibraryAsync({ quality: 0.9 });

      if (picker.canceled) {
        setLoading(false);
        return;
      }
      const asset = picker.assets[0];

      const manipulated = await ImageManipulator.manipulateAsync(
        asset.uri,
        [{ resize: { width: 640 } }],
        { compress: 0.9, format: ImageManipulator.SaveFormat.JPEG, base64: true },
      );

      if (!manipulated.base64) throw new Error("Failed to get base64");

      const dataUri = `data:image/jpeg;base64,${manipulated.base64}`;
      setPreview(manipulated.uri);
      setLastDataUri(dataUri);

      const resp = await scoreImage({
        dataUri,
        poseId: "generic",
        includeLandmarks: showSkeleton,
      });
      if (!resp.ok) {
        throw new Error(resp.error || "Score failed");
      }
      setResult(resp.data!);
    } catch (e: any) {
      console.error(e);
      Alert.alert("Upload failed", e?.message || "Please check permissions or network and try again.");
    } finally {
      setLoading(false);
      setSkeletonError(false);
    }
  }

  useEffect(() => {
    if (!showSkeleton) return;
    if (!result || result.landmarks?.length) return;
    if (!lastDataUri || loading || overlayLoading || skeletonError) return;

    let active = true;
    (async () => {
      try {
        setOverlayLoading(true);
        const resp = await scoreImage({
          dataUri: lastDataUri,
          poseId: "generic",
          includeLandmarks: true,
        });
        if (!active) return;
        if (!resp.ok) {
          Alert.alert("Skeleton unavailable", resp.error || "Failed to fetch landmarks.");
          setSkeletonError(true);
          return;
        }
        setResult(resp.data!);
        setSkeletonError(false);
      } catch (err: any) {
        if (!active) return;
        console.error(err);
        Alert.alert("Skeleton unavailable", err?.message || "Unable to load landmarks.");
        setSkeletonError(true);
      } finally {
        if (active) {
          setOverlayLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, [showSkeleton, result, lastDataUri, loading, overlayLoading, skeletonError]);

  const metricEntries = useMemo(() => {
    if (!result?.metrics) return [];
    return Object.entries(result.metrics).map(([key, value]) => ({ key, value }));
  }, [result?.metrics]);

  const formatMetricValue = useCallback((value: unknown) => {
    if (typeof value === "number" && Number.isFinite(value)) {
      const abs = Math.abs(value);
      if (abs >= 10) return value.toFixed(1);
      if (abs >= 1) return value.toFixed(2);
      return value.toFixed(3);
    }
    return String(value);
  }, []);

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }}>
      <Text style={styles.headerTitle}>SmartYoga · Pose Scoring</Text>
      <Text style={styles.headerSubtitle}>
        Capture or pick a pose photo to receive instant feedback, or enable realtime stream monitoring.
      </Text>

      <View style={{ flexDirection: "row", gap: 12 }}>
        <Pressable
          onPress={() => pick("camera")}
          style={[styles.primaryButton, { backgroundColor: "#111827" }]}
        >
          <Text style={styles.primaryButtonText}>📷 Take Photo</Text>
        </Pressable>
        <Pressable
          onPress={() => pick("library")}
          style={[styles.primaryButton, { backgroundColor: "#374151" }]}
        >
          <Text style={styles.primaryButtonText}>🖼️ Pick from Library</Text>
        </Pressable>
      </View>

      <View style={styles.switchRow}>
        <Text style={styles.switchLabel}>Show skeleton overlay</Text>
        <Switch
          value={showSkeleton}
          onValueChange={(value) => {
            setShowSkeleton(value);
            if (value) {
              setSkeletonError(false);
            }
          }}
        />
      </View>

      {(loading || overlayLoading) && (
        <View style={{ paddingVertical: 16, flexDirection: "row", alignItems: "center", gap: 8 }}>
          <ActivityIndicator />
          <Text>{loading ? "Scoring…" : "Loading skeleton…"}</Text>
        </View>
      )}

      {preview && (
        <View style={styles.previewContainer} onLayout={onImageLayout}>
          <Image source={{ uri: preview }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
          {showSkeleton && result?.landmarks?.length ? (
            <PoseOverlay landmarks={result.landmarks} width={canvasSize.width} height={canvasSize.height} />
          ) : null}
          {showSkeleton && skeletonError && !overlayLoading ? (
            <View style={styles.overlayNotice}>
              <Text style={styles.overlayNoticeText}>Skeleton overlay unavailable</Text>
            </View>
          ) : null}
        </View>
      )}

      <View style={styles.sectionCard}>
        <View style={styles.switchRow}>
          <Text style={styles.sectionTitle}>Realtime Coach Feed</Text>
          <Switch value={watchRealtime} onValueChange={setWatchRealtime} />
        </View>
        {watchRealtime ? (
          <View style={{ gap: 8 }}>
            <Text style={styles.caption}>
              Pose stream:{" "}
              <Text style={styles.statusValue}>
                {poseStream.connected ? "live" : poseStream.error ? `error (${poseStream.error})` : "connecting…"}
              </Text>
              {"  "}Signaling:{" "}
              <Text style={styles.statusValue}>
                {signaling.connected ? "connected" : signaling.error ? `error (${signaling.error})` : "connecting…"}
              </Text>
            </Text>
            <Text style={styles.caption}>
              Peer ID: <Text style={styles.statusValue}>{signaling.peerId}</Text> · Peers online:{" "}
              {signaling.peers.length}
            </Text>
            {signaling.peers.length ? (
              <View style={{ gap: 4 }}>
                {signaling.peers.map((peer) => (
                  <Text key={peer.peerId} style={styles.peerBadge}>
                    👥 {peer.peerId} · {new Date(peer.lastSeen).toLocaleTimeString()}
                  </Text>
                ))}
              </View>
            ) : null}
            {latestPoseEvent ? (
              <View style={styles.poseEventBox}>
                <Text style={styles.poseEventTitle}>
                  Last frame · {new Date(latestPoseEvent.ts).toLocaleTimeString()}
                </Text>
                <Text style={styles.caption}>
                  Poses detected: <Text style={styles.statusValue}>{latestPoseEvent.poses.length}</Text>
                </Text>
                <View style={{ gap: 4 }}>
                  {latestPoseEvent.poses.slice(0, 3).map((pose, idx) => (
                    <Text key={`${pose.track_id ?? pose.tracking_id ?? idx}`} style={styles.poseEventDetail}>
                      • Track #{pose.track_id ?? pose.tracking_id ?? idx + 1} · conf{" "}
                      {(pose.confidence ?? 0).toFixed(2)}
                    </Text>
                  ))}
                </View>
              </View>
            ) : (
              <Text style={styles.caption}>Awaiting frames…</Text>
            )}
            <Text style={styles.captionMuted}>
              Streaming from {poseStreamUrl} · signaling via {signalingUrl}
            </Text>
          </View>
        ) : (
          <Text style={styles.caption}>
            Enable to monitor live pose events and room presence. Streams via SSE and the WebRTC signaling server.
          </Text>
        )}
      </View>

      {result && (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>Score: {result.score}</Text>
          <Text style={styles.resultAdvice}>{result.advice}</Text>
          <Text style={styles.resultSummary}>{result.summary}</Text>

          {metricEntries.length > 0 && (
            <View style={{ marginTop: 10, gap: 6 }}>
              <Text style={{ fontWeight: "600" }}>Metrics</Text>
              <View style={styles.metricGrid}>
                {metricEntries.map(({ key, value }) => (
                  <View key={key} style={styles.metricItem}>
                    <Text style={styles.metricKey}>{METRIC_LABELS[key] ?? key}</Text>
                    <Text style={styles.metricValue}>{formatMetricValue(value)}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#111827",
  },
  headerSubtitle: {
    color: "#6b7280",
    fontSize: 14,
  },
  primaryButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  primaryButtonText: {
    color: "white",
    fontWeight: "600",
  },
  previewContainer: {
    width: "100%",
    aspectRatio: 3 / 4,
    borderRadius: 12,
    overflow: "hidden",
    backgroundColor: "#e5e7eb",
    position: "relative",
  },
  switchRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  switchLabel: {
    fontSize: 15,
    color: "#374151",
    fontWeight: "500",
  },
  overlayNotice: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(17, 24, 39, 0.45)",
    alignItems: "center",
    justifyContent: "center",
  },
  overlayNoticeText: {
    color: "#F9FAFB",
    fontWeight: "600",
    fontSize: 14,
  },
  sectionCard: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 16,
    gap: 8,
    shadowColor: "#1f2937",
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  caption: {
    color: "#4b5563",
    fontSize: 14,
  },
  captionMuted: {
    color: "#9ca3af",
    fontSize: 12,
  },
  statusValue: {
    fontWeight: "600",
    color: "#111827",
  },
  peerBadge: {
    backgroundColor: "#e0f2fe",
    color: "#0c4a6e",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    fontSize: 13,
  },
  poseEventBox: {
    backgroundColor: "#f9fafb",
    borderRadius: 10,
    padding: 12,
    gap: 4,
  },
  poseEventTitle: {
    fontWeight: "600",
    fontSize: 15,
    color: "#1f2937",
  },
  poseEventDetail: {
    color: "#374151",
    fontSize: 13,
  },
  resultCard: {
    backgroundColor: "#F5F3FF",
    padding: 14,
    borderRadius: 14,
    gap: 6,
  },
  resultTitle: {
    fontSize: 20,
    fontWeight: "700",
  },
  resultAdvice: {
    fontSize: 16,
    color: "#111827",
  },
  resultSummary: {
    color: "#6b7280",
  },
  metricGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  metricItem: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: "#E0E7FF",
  },
  metricKey: {
    fontSize: 12,
    textTransform: "capitalize",
    color: "#4338CA",
    marginBottom: 2,
  },
  metricValue: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
  },
});
