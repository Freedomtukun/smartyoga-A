import { create } from 'zustand';

export interface SessionSnapshot {
  sessionId: string;
  score: number;
  advice: string[];
  summary?: string;
  timestamp: number;
}

interface SessionState {
  currentSessionId: string | null;
  snapshot: SessionSnapshot | null;
  history: SessionSnapshot[];
  setSession: (sessionId: string) => void;
  updateSnapshot: (snapshot: Omit<SessionSnapshot, 'timestamp'> & { timestamp?: number }) => void;
}

export const useSessionStore = create<SessionState>((set, get) => ({
  currentSessionId: null,
  snapshot: null,
  history: [],
  setSession: (sessionId) => set({ currentSessionId: sessionId, snapshot: null }),
  updateSnapshot: (snapshot) => {
    const timestamp = snapshot.timestamp ?? Date.now();
    const entry = { ...snapshot, timestamp } as SessionSnapshot;
    set({ snapshot: entry, history: [entry, ...get().history].slice(0, 20) });
  },
}));
