import { CameraView, useCameraPermissions } from 'expo-camera';
import React, { useEffect, useMemo, useState } from 'react';
import { Linking, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import { login, register } from '../api/auth';
import { createSession } from '../api/sessions';
import { speak } from '../api/tts';
import { VoiceFeedbackButton } from '../components/VoiceFeedbackButton';
import { ScoreCard } from '../components/ScoreCard';
import { usePoseStreaming } from '../hooks/usePoseStreaming';
import { useSessionStore } from '../store/useSessionStore';
import { playRemoteAudio } from '../utils/audio';

export function HomeScreen() {
  const navigation = useNavigation();
  const [permission, requestPermission] = useCameraPermissions();
  const [token, setToken] = useState<string | null>(null);
  const [voiceLoading, setVoiceLoading] = useState(false);
  const sessionId = useSessionStore((state) => state.currentSessionId);
  const setSession = useSessionStore((state) => state.setSession);
  const snapshot = useSessionStore((state) => state.snapshot);
  const email = useMemo(() => `mobile-${Date.now()}@example.ca`, []);

  useEffect(() => {
    if (!permission) {
      requestPermission();
    }
  }, [permission, requestPermission]);

  useEffect(() => {
    async function bootstrap() {
      try {
        const result = await login({ email, password: 'DemoPass123' });
        setToken(result.access_token);
      } catch (error) {
        await register({ email, password: 'DemoPass123', display_name: 'Mobile Demo', locale: 'en-CA' });
        const result = await login({ email, password: 'DemoPass123' });
        setToken(result.access_token);
      }
    }
    if (!token) {
      bootstrap();
    }
  }, [token, email]);

  useEffect(() => {
    async function ensureSession() {
      if (!token || sessionId) return;
      const session = await createSession(token, {
        device_id: 'mobile-app',
        pose_profile: 'vinyasa-basic',
        notes: 'Auto created session',
        app_version: '0.1.0',
      });
      setSession(session.session_id);
    }
    ensureSession();
  }, [token, sessionId, setSession]);

  const { streaming } = usePoseStreaming(token, sessionId);

  const handleVoiceFeedback = async () => {
    if (!token || !sessionId || !snapshot) return;
    setVoiceLoading(true);
    try {
      const tts = await speak(token, snapshot.summary || 'Keep your posture aligned', sessionId);
      await playRemoteAudio(tts.audio_url);
    } catch (error) {
      console.warn('Failed to play voice feedback', error);
    } finally {
      setVoiceLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>SmartYoga Canada</Text>
      <View style={styles.cameraWrapper}>
        {permission?.granted ? (
          <CameraView style={styles.camera} facing="front" />
        ) : (
          <View style={[styles.camera, styles.cameraPlaceholder]}>
            <Text style={styles.placeholderText}>Camera permission required.</Text>
            <Text style={styles.link} onPress={() => Linking.openSettings()}>
              Open settings
            </Text>
          </View>
        )}
      </View>
      <View style={styles.statusRow}>
        <Text style={styles.statusDot} />
        <Text style={styles.statusText}>{streaming ? 'Streaming pose data' : 'Waiting for session'}</Text>
      </View>
      <ScoreCard snapshot={snapshot} />
      <VoiceFeedbackButton loading={voiceLoading} onPress={handleVoiceFeedback} />
      <Text style={styles.link} onPress={() => navigation.navigate('History' as never)}>View session history</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F0F',
  },
  content: {
    padding: 20,
    gap: 20,
  },
  title: {
    color: '#F5F7F8',
    fontSize: 24,
    fontWeight: '700',
  },
  cameraWrapper: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  camera: {
    width: '100%',
    height: 320,
  },
  cameraPlaceholder: {
    backgroundColor: '#1B1B1B',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  placeholderText: {
    color: '#A0A0A0',
  },
  link: {
    color: '#1A9A8B',
    textAlign: 'center',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#1AFAAF',
  },
  statusText: {
    color: '#A0A0A0',
  },
});
