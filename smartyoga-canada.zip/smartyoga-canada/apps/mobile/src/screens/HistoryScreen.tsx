import React from 'react';
import { FlatList, SafeAreaView, StyleSheet, Text, View } from 'react-native';

import { useSessionStore } from '../store/useSessionStore';

export function HistoryScreen() {
  const history = useSessionStore((state) => state.history);
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        contentContainerStyle={styles.list}
        data={history}
        keyExtractor={(item) => `${item.sessionId}-${item.timestamp}`}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.score}>Score {item.score}</Text>
            <Text style={styles.summary}>{item.summary || 'Solid posture'}</Text>
            {item.advice.map((tip) => (
              <Text key={tip} style={styles.tip}>
                • {tip}
              </Text>
            ))}
            <Text style={styles.timestamp}>{new Date(item.timestamp).toLocaleString()}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No sessions recorded yet.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F0F',
  },
  list: {
    padding: 20,
    gap: 12,
  },
  card: {
    backgroundColor: '#141414',
    borderRadius: 12,
    padding: 16,
    gap: 8,
  },
  score: {
    color: '#1AFAAF',
    fontSize: 18,
    fontWeight: '700',
  },
  summary: {
    color: '#F5F7F8',
  },
  tip: {
    color: '#C4C4C4',
  },
  timestamp: {
    color: '#707070',
    fontSize: 12,
  },
  empty: {
    color: '#A0A0A0',
    textAlign: 'center',
    marginTop: 80,
  },
});
