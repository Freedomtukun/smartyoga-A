import { Audio } from 'expo-av';

export async function playRemoteAudio(url: string) {
  const { sound } = await Audio.Sound.createAsync({ uri: url });
  await sound.playAsync();
  sound.setOnPlaybackStatusUpdate((status) => {
    if (!status.isLoaded || status.didJustFinish) {
      sound.unloadAsync();
    }
  });
  return sound;
}
