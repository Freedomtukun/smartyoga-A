import { useEffect, useRef, useState } from 'react';

import { pushFrame } from '../api/sessions';
import { useSessionStore } from '../store/useSessionStore';

const SAMPLE_LANDMARKS = [
  { name: 'LEFT_SHOULDER', x: 0.45, y: 0.32, visibility: 0.98 },
  { name: 'RIGHT_SHOULDER', x: 0.54, y: 0.33, visibility: 0.96 },
  { name: 'LEFT_HIP', x: 0.48, y: 0.60, visibility: 0.94 },
  { name: 'RIGHT_HIP', x: 0.51, y: 0.61, visibility: 0.91 },
];

export function usePoseStreaming(token: string | null, sessionId: string | null) {
  const [streaming, setStreaming] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const updateSnapshot = useSessionStore((state) => state.updateSnapshot);

  useEffect(() => {
    if (!token || !sessionId) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setStreaming(false);
      return;
    }
    setStreaming(true);
    timerRef.current = setInterval(async () => {
      try {
        const payload = {
          timestamp_ms: Date.now() % 10000,
          pose_landmarks: SAMPLE_LANDMARKS,
        };
        const result = await pushFrame(token, sessionId, payload);
        updateSnapshot({
          sessionId,
          score: result.score,
          advice: result.advice,
          summary: result.summary,
        });
      } catch (error) {
        console.warn('Pose streaming failed', error);
      }
    }, 4000);
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setStreaming(false);
    };
  }, [token, sessionId, updateSnapshot]);

  return { streaming };
}
