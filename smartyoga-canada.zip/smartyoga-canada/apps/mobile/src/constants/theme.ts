import { DefaultTheme, Theme } from '@react-navigation/native';

const brand = {
  primary: '#1A9A8B',
  background: '#0F0F0F',
  text: '#F5F7F8',
  card: '#141414',
  border: '#1F1F1F',
};

export const theme: { navigation: Theme } = {
  navigation: {
    ...DefaultTheme,
    colors: {
      ...DefaultTheme.colors,
      primary: brand.primary,
      background: brand.background,
      text: brand.text,
      card: brand.card,
      border: brand.border,
      notification: brand.primary,
    },
  },
};
