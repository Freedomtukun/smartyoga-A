import { apiClient } from './client';

export async function speak(token: string, text: string, sessionId?: string) {
  const response = await apiClient.post(
    '/tts/speak',
    { text, session_id: sessionId },
    { headers: { Authorization: `Bearer ${token}` } },
  );
  return response.data as { audio_url: string; duration_ms: number; engine: string };
}
