import { apiClient } from './client';

interface Credentials {
  email: string;
  password: string;
}

export async function login(credentials: Credentials) {
  const response = await apiClient.post('/auth/login', credentials);
  return response.data as { access_token: string; refresh_token: string; user_id: string };
}

export async function register(payload: Credentials & { display_name: string; locale: string }) {
  const response = await apiClient.post('/auth/register', payload);
  return response.data;
}
