import { apiClient } from './client';

interface CreateSessionPayload {
  device_id: string;
  pose_profile: string;
  notes?: string;
  app_version: string;
}

export async function createSession(token: string, payload: CreateSessionPayload) {
  const response = await apiClient.post('/sessions', payload, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
}

interface PoseFramePayload {
  timestamp_ms: number;
  pose_landmarks: Array<{ name: string; x: number; y: number; z?: number; visibility?: number }>;
}

export async function pushFrame(token: string, sessionId: string, payload: PoseFramePayload) {
  const response = await apiClient.post(`/sessions/${sessionId}/frames`, payload, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
}
