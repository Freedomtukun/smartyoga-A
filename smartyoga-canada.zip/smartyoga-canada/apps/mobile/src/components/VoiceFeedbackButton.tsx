import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';

interface VoiceFeedbackButtonProps {
  loading: boolean;
  onPress: () => void;
}

export function VoiceFeedbackButton({ loading, onPress }: VoiceFeedbackButtonProps) {
  return (
    <Pressable style={styles.button} onPress={onPress} disabled={loading}>
      {loading ? <ActivityIndicator color="#0F0F0F" /> : <Text style={styles.label}>Play Advice</Text>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#1A9A8B',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  label: {
    color: '#0F0F0F',
    fontSize: 16,
    fontWeight: '600',
  },
});
