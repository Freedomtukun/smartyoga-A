import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { SessionSnapshot } from '../store/useSessionStore';

interface ScoreCardProps {
  snapshot: SessionSnapshot | null;
}

export function ScoreCard({ snapshot }: ScoreCardProps) {
  if (!snapshot) {
    return (
      <View style={[styles.card, styles.empty]}>
        <Text style={styles.heading}>Ready to start</Text>
        <Text style={styles.body}>Stand in frame and begin your pose.</Text>
      </View>
    );
  }
  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Score</Text>
      <Text style={styles.score}>{snapshot.score}</Text>
      <Text style={styles.heading}>Advice</Text>
      {snapshot.advice.map((tip) => (
        <Text key={tip} style={styles.body}>
          • {tip}
        </Text>
      ))}
      {snapshot.summary ? (
        <Text style={[styles.body, styles.summary]}>{snapshot.summary}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#141414',
    borderRadius: 16,
    padding: 20,
    gap: 8,
  },
  empty: {
    borderWidth: 1,
    borderColor: '#2A2A2A',
  },
  heading: {
    color: '#A0A0A0',
    fontSize: 14,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  score: {
    color: '#1AFAAF',
    fontSize: 42,
    fontWeight: '700',
  },
  body: {
    color: '#F5F7F8',
    fontSize: 16,
  },
  summary: {
    marginTop: 12,
    fontStyle: 'italic',
  },
});
