import { createServer } from "http";
import express from "express";
import pino from "pino";
import { WebSocketServer } from "ws";
import { v4 as uuidv4 } from "uuid";

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();

const PORT = Number(process.env.SIGNALING_PORT || process.env.PORT || 8600);
const HEARTBEAT_INTERVAL = 30_000;
const rooms = new Map();

app.get("/healthz", (req, res) => {
  res.json({ status: "ok", service: "signaling", rooms: rooms.size });
});

const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/signal" });
log.info({ port: PORT }, "Signaling server listening");

wss.on("connection", (socket, request) => {
  const connectionId = uuidv4();
  socket.id = connectionId;
  socket.isAlive = true;
  log.info({ connectionId, ip: request.socket.remoteAddress }, "ws connected");

  socket.on("pong", () => {
    socket.isAlive = true;
  });

  socket.on("message", (message) => {
    try {
      const payload = JSON.parse(message.toString());
      handleMessage(socket, payload);
    } catch (err) {
      log.warn({ err }, "invalid payload");
      socket.send(JSON.stringify({ type: "error", code: "invalid_payload" }));
    }
  });

  socket.on("close", () => {
    log.info({ connectionId }, "socket closed");
    leaveRoom(socket);
  });

  socket.on("error", (err) => {
    log.warn({ err, connectionId }, "socket error");
  });
});

function handleMessage(socket, payload) {
  switch (payload?.type) {
    case "join":
      joinRoom(socket, payload);
      break;
    case "signal":
      forwardSignal(socket, payload);
      break;
    case "leave":
      leaveRoom(socket);
      break;
    case "ping":
      socket.send(JSON.stringify({ type: "pong", ts: Date.now() }));
      break;
    default:
      socket.send(JSON.stringify({ type: "error", code: "unsupported_type", detail: payload?.type }));
  }
}

function joinRoom(socket, payload) {
  const roomId = payload?.roomId;
  const peerId = payload?.peerId || uuidv4();
  if (!roomId) {
    socket.send(JSON.stringify({ type: "error", code: "room_required" }));
    return;
  }
  leaveRoom(socket);

  if (!rooms.has(roomId)) {
    rooms.set(roomId, new Map());
  }
  const peers = rooms.get(roomId);
  peers.set(socket.id, { peerId, socket });
  socket.roomId = roomId;
  socket.peerId = peerId;

  const others = [...peers.entries()]
    .filter(([id]) => id !== socket.id)
    .map(([, info]) => ({ peerId: info.peerId }));

  socket.send(JSON.stringify({ type: "joined", roomId, peerId, peers: others }));

  for (const [id, info] of peers.entries()) {
    if (id === socket.id) continue;
    info.socket.send(JSON.stringify({ type: "peer.joined", roomId, peerId }));
  }

  log.info({ roomId, peerId, connectionId: socket.id }, "peer joined room");
}

function forwardSignal(socket, payload) {
  const roomId = socket.roomId;
  if (!roomId) {
    socket.send(JSON.stringify({ type: "error", code: "not_joined" }));
    return;
  }
  const targetPeer = payload?.targetPeerId;
  if (!targetPeer) {
    socket.send(JSON.stringify({ type: "error", code: "target_required" }));
    return;
  }

  const peers = rooms.get(roomId);
  if (!peers) {
    socket.send(JSON.stringify({ type: "error", code: "room_closed" }));
    return;
  }

  for (const { peerId, socket: peerSocket } of peers.values()) {
    if (peerId === targetPeer) {
      peerSocket.send(
        JSON.stringify({
          type: "signal",
          roomId,
          fromPeerId: socket.peerId,
          data: payload?.data ?? null,
        }),
      );
      return;
    }
  }

  socket.send(JSON.stringify({ type: "error", code: "peer_not_found", targetPeerId: targetPeer }));
}

function leaveRoom(socket) {
  const roomId = socket.roomId;
  if (!roomId) return;

  const peers = rooms.get(roomId);
  if (!peers) return;

  const entry = peers.get(socket.id);
  peers.delete(socket.id);
  socket.roomId = null;

  if (entry) {
    for (const { socket: peerSocket } of peers.values()) {
      peerSocket.send(JSON.stringify({ type: "peer.left", roomId, peerId: entry.peerId }));
    }
    log.info({ roomId, peerId: entry.peerId }, "peer left room");
  }

  if (peers.size === 0) {
    rooms.delete(roomId);
  }
}

const interval = setInterval(() => {
  for (const client of wss.clients) {
    if (client.isAlive === false) {
      client.terminate();
      continue;
    }
    client.isAlive = false;
    client.ping();
  }
}, HEARTBEAT_INTERVAL);

wss.on("close", () => {
  clearInterval(interval);
});

server.listen(PORT);
