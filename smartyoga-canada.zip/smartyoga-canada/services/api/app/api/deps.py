from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

from ..core.security import decode_token
from ..db.fake import get_db

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db=Depends(get_db)):
    try:
        payload = decode_token(token)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail={"error_code": "E1006", "message": "Unauthorized"}) from exc
    user_id = payload.get("sub")
    user = db.get_user(user_id) if user_id else None
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail={"error_code": "E1006", "message": "Unauthorized"})
    return user


def require_admin(user=Depends(get_current_user)):
    if user.membership_tier != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail={"error_code": "E1007", "message": "Forbidden"})
    return user
