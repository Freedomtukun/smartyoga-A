from datetime import datetime

from fastapi import APIRouter, Depends

from ...schemas.tts import TTSRequest, TTSResponse
from ...services.tts_client import tts_client
from ..deps import get_current_user

router = APIRouter(prefix="/tts", tags=["tts"])


@router.post("/speak", response_model=TTSResponse)
async def speak(payload: TTSRequest, user=Depends(get_current_user)) -> TTSResponse:
    _ = user  # ensure auth required
    result = await tts_client.synthesize(payload.model_dump())
    return TTSResponse(
        audio_url=result.get("audio_url", "https://cdn.smartyoga.ca/audio/demo.mp3"),
        duration_ms=int(result.get("duration_ms", 4200)),
        engine=result.get("engine", "piper"),
    )
