from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status

from ...db.fake import get_db
from ...schemas.sessions import (
    PoseFramePayload,
    PoseFramePreview,
    PoseInferenceResult,
    SessionCreateRequest,
    SessionDetail,
    SessionSummary,
)
from ...services.pose_client import pose_client
from ..deps import get_current_user

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.post("", response_model=SessionSummary, status_code=status.HTTP_201_CREATED)
async def create_session(payload: SessionCreateRequest, user=Depends(get_current_user), db=Depends(get_db)) -> SessionSummary:
    session = db.create_session(user.user_id, payload.pose_profile, payload.notes)
    return SessionSummary(
        session_id=session.session_id,
        user_id=session.user_id,
        pose_profile=session.pose_profile,
        score=session.score,
        advice=session.advice,
        summary=session.summary,
        started_at=session.started_at,
        ended_at=session.ended_at,
        status=session.status,
    )


@router.get("/{session_id}", response_model=SessionDetail)
async def get_session_detail(session_id: str, user=Depends(get_current_user), db=Depends(get_db)) -> SessionDetail:
    session = db.get_session(session_id)
    if not session or session.user_id != user.user_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail={"error_code": "E1008", "message": "NotFound"})
    frames = [frame for frame in db.frames.values() if frame.session_id == session_id]
    previews = [PoseFramePreview(frame_id=f.frame_id, timestamp_ms=f.timestamp_ms, score=f.score) for f in frames]
    return SessionDetail(
        session_id=session.session_id,
        user_id=session.user_id,
        pose_profile=session.pose_profile,
        score=session.score,
        advice=session.advice,
        summary=session.summary,
        started_at=session.started_at,
        ended_at=session.ended_at,
        status=session.status,
        frames=previews,
    )


@router.post("/{session_id}/frames", response_model=PoseInferenceResult)
async def push_frame(session_id: str, payload: PoseFramePayload, user=Depends(get_current_user), db=Depends(get_db)) -> PoseInferenceResult:
    session = db.get_session(session_id)
    if not session or session.user_id != user.user_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail={"error_code": "E1008", "message": "NotFound"})

    pose_request = {
        "session_id": session_id,
        "pose_profile": session.pose_profile,
        "pose_landmarks": [landmark.model_dump() for landmark in payload.pose_landmarks],
    }
    result = await pose_client.infer(pose_request)
    score = int(result.get("score", 80))
    advice = result.get("advice", ["Maintain steady breathing"])
    summary = result.get("summary", "Strong posture")
    confidence = float(result.get("confidence", 0.9))
    recorded_frame = db.add_frame(session_id, score, advice, summary, confidence, payload.timestamp_ms, frame_id=payload.frame_id)
    session.score = score
    session.advice = advice
    session.summary = summary
    session.ended_at = datetime.utcnow()
    return PoseInferenceResult(
        session_id=session_id,
        frame_id=recorded_frame.frame_id,
        score=score,
        advice=advice,
        summary=summary,
        confidence=confidence,
        pose_service_latency_ms=int(result.get("latency_ms", 85)),
    )
