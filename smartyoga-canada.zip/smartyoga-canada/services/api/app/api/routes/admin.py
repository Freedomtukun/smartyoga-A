import random
from datetime import datetime

from fastapi import APIRouter, Depends

from ...schemas.admin import SystemMetrics
from ..deps import require_admin

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/system-metrics", response_model=SystemMetrics)
async def system_metrics(user=Depends(require_admin)) -> SystemMetrics:
    uptime = int((datetime.utcnow().timestamp()) % 86400)
    return SystemMetrics(
        uptime_s=uptime,
        pose_queue_depth=random.randint(0, 5),
        tts_queue_depth=random.randint(0, 3),
        active_sessions=random.randint(1, 20),
        stripe_payout_status="ok",
    )
