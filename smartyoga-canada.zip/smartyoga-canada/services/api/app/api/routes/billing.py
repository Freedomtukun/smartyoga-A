from datetime import datetime

from fastapi import APIRouter, Depends

from ...schemas.billing import CheckoutRequest, CheckoutSession, SubscriptionStatus
from ...services.billing import billing_service
from ..deps import get_current_user

router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/checkout", response_model=CheckoutSession)
async def checkout(payload: CheckoutRequest, user=Depends(get_current_user)) -> CheckoutSession:
    url, session_id, expires_at = billing_service.create_checkout_session(user.user_id, payload.plan_id, payload.success_url, payload.cancel_url)
    return CheckoutSession(checkout_url=url, stripe_session_id=session_id, expires_at=expires_at)


@router.get("/subscription", response_model=SubscriptionStatus)
async def subscription(user=Depends(get_current_user)) -> SubscriptionStatus:
    renew_at = datetime.utcnow()
    return SubscriptionStatus(
        user_id=user.user_id,
        membership_tier=user.membership_tier,
        status="active" if user.membership_tier == "premium" else "inactive",
        renew_at=renew_at,
        stripe_subscription_id="sub_test" if user.membership_tier == "premium" else None,
    )


@router.post("/webhook")
async def webhook(payload: dict) -> dict:
    # Minimal verification stub for local dev
    return {"received": True}
