import time
from datetime import datetime

from fastapi import APIRouter

from ...schemas.common import HealthStatus

router = APIRouter(prefix="", tags=["health"])

start_time = time.time()


@router.get("/healthz", response_model=HealthStatus)
async def healthz() -> HealthStatus:
    uptime = int(time.time() - start_time)
    return HealthStatus(
        status="ok",
        timestamp=datetime.utcnow(),
        uptime_s=uptime,
        pose_service_latency_ms=85,
        tts_service_latency_ms=40,
    )
