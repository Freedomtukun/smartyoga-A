from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status

from ...core.security import create_access_token, hash_password, verify_password
from ...db.fake import RefreshToken, get_db
from ...schemas.auth import AuthResponse, LoginRequest, RegisterRequest, TokenRefreshRequest

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db=Depends(get_db)) -> AuthResponse:
    try:
        user = db.create_user(payload.email, payload.password, payload.display_name, payload.locale)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail={"error_code": "E1004", "message": "EmailExists"}) from exc

    access_token = create_access_token(user.user_id, timedelta(minutes=60))
    refresh_plain = create_access_token(user.user_id, timedelta(days=7))
    db.create_refresh_token(user.user_id, hash_password(refresh_plain))
    return AuthResponse(
        user_id=user.user_id,
        access_token=access_token,
        refresh_token=refresh_plain,
        expires_in=3600,
        issued_at=datetime.utcnow(),
    )


@router.post("/login", response_model=AuthResponse)
async def login(payload: LoginRequest, db=Depends(get_db)) -> AuthResponse:
    user = db.get_user_by_email(payload.email)
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail={"error_code": "E1001", "message": "AuthenticationFailed"})

    access_token = create_access_token(user.user_id, timedelta(minutes=60))
    refresh_plain = create_access_token(user.user_id, timedelta(days=7))
    db.create_refresh_token(user.user_id, hash_password(refresh_plain))
    return AuthResponse(
        user_id=user.user_id,
        access_token=access_token,
        refresh_token=refresh_plain,
        expires_in=3600,
        issued_at=datetime.utcnow(),
    )


@router.post("/token/refresh", response_model=AuthResponse)
async def refresh(payload: TokenRefreshRequest, db=Depends(get_db)) -> AuthResponse:
    for token in db.tokens.values():
        if verify_password(payload.refresh_token, token.hashed_token):
            if token.expires_at < datetime.utcnow():
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail={"error_code": "E1002", "message": "TokenExpired"})
            user = db.get_user(token.user_id)
            if not user:
                break
            new_access = create_access_token(user.user_id, timedelta(minutes=60))
            new_refresh_plain = create_access_token(user.user_id, timedelta(days=7))
            db.create_refresh_token(user.user_id, hash_password(new_refresh_plain))
            return AuthResponse(
                user_id=user.user_id,
                access_token=new_access,
                refresh_token=new_refresh_plain,
                expires_in=3600,
                issued_at=datetime.utcnow(),
            )
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail={"error_code": "E1003", "message": "TokenInvalid"})
