from fastapi import APIRouter, Depends

from ...db.fake import get_db
from ...schemas.users import UserProfile, UserUpdateRequest
from ..deps import get_current_user

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserProfile)
async def me(user=Depends(get_current_user)) -> UserProfile:
    return UserProfile(**user.__dict__)


@router.patch("/me", response_model=UserProfile)
async def update_me(payload: UserUpdateRequest, user=Depends(get_current_user), db=Depends(get_db)) -> UserProfile:
    updated = db.update_user(user.user_id, display_name=payload.display_name, locale=payload.locale)
    return UserProfile(**updated.__dict__)
