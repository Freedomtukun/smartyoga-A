from fastapi import APIRouter, Depends

from ...schemas.analytics import AnalyticsAccepted, AnalyticsEvent
from ...services.analytics import analytics_service
from ..deps import get_current_user

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.post("/events", response_model=AnalyticsAccepted)
async def track_event(payload: AnalyticsEvent, user=Depends(get_current_user)) -> AnalyticsAccepted:
    event = payload.model_dump()
    event["user_id"] = user.user_id
    batch_id = await analytics_service.publish_event(event)
    return AnalyticsAccepted(accepted=True, batch_id=batch_id)
