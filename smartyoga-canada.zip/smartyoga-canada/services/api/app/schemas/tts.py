from pydantic import BaseModel, Field


class TTSRequest(BaseModel):
    text: str = Field(min_length=1)
    voice_id: str = Field(default="en_CA_female_1")
    session_id: str | None = None
    fallback: str | None = Field(default="coqui")


class TTSResponse(BaseModel):
    audio_url: str
    duration_ms: int
    engine: str
