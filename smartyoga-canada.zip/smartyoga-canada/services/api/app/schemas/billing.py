from datetime import datetime
from pydantic import BaseModel, Field


class CheckoutRequest(BaseModel):
    plan_id: str = Field(min_length=1)
    success_url: str
    cancel_url: str


class CheckoutSession(BaseModel):
    checkout_url: str
    stripe_session_id: str
    expires_at: datetime


class SubscriptionStatus(BaseModel):
    user_id: str
    membership_tier: str
    status: str
    renew_at: datetime | None = None
    stripe_subscription_id: str | None = None
