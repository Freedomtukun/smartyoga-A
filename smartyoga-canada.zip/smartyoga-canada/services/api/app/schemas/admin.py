from pydantic import BaseModel


class SystemMetrics(BaseModel):
    uptime_s: int
    pose_queue_depth: int
    tts_queue_depth: int
    active_sessions: int
    stripe_payout_status: str
