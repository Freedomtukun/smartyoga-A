from datetime import datetime
from pydantic import BaseModel, Field


class HealthStatus(BaseModel):
    status: str = "ok"
    timestamp: datetime
    uptime_s: int
    pose_service_latency_ms: int | None = None
    tts_service_latency_ms: int | None = None


class APIError(BaseModel):
    error_code: str = Field(..., examples=["E1006"])
    message: str
    detail: dict | None = None
