from datetime import datetime
from pydantic import BaseModel, EmailStr, Field


class UserProfile(BaseModel):
    user_id: str
    email: EmailStr
    display_name: str
    locale: str
    membership_tier: str = "free"
    stripe_customer_id: str | None = None
    created_at: datetime
    updated_at: datetime


class UserUpdateRequest(BaseModel):
    display_name: str | None = Field(default=None, max_length=60)
    locale: str | None = Field(default=None)
