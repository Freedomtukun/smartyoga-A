from datetime import datetime
from pydantic import BaseModel, EmailStr, Field, constr


class RegisterRequest(BaseModel):
    email: EmailStr
    password: constr(min_length=8)  # type: ignore[valid-type]
    display_name: constr(min_length=1, max_length=60)  # type: ignore[valid-type]
    locale: str = Field(default="en-CA")


class LoginRequest(BaseModel):
    email: EmailStr
    password: constr(min_length=8)  # type: ignore[valid-type]


class TokenRefreshRequest(BaseModel):
    refresh_token: str


class AuthResponse(BaseModel):
    user_id: str
    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"
    issued_at: datetime
