from datetime import datetime
from pydantic import BaseModel, Field


class AnalyticsEvent(BaseModel):
    session_id: str | None = None
    event_name: str = Field(min_length=1)
    emitted_at: datetime
    payload: dict = Field(default_factory=dict)


class AnalyticsAccepted(BaseModel):
    accepted: bool
    batch_id: str
