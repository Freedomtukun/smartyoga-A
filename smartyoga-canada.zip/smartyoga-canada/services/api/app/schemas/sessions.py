from datetime import datetime
from pydantic import BaseModel, Field


class PoseLandmark(BaseModel):
    name: str
    x: float
    y: float
    z: float | None = None
    visibility: float | None = None


class SessionCreateRequest(BaseModel):
    device_id: str = Field(min_length=1)
    pose_profile: str
    notes: str | None = None
    app_version: str


class SessionSummary(BaseModel):
    session_id: str
    user_id: str
    pose_profile: str
    score: int | None = None
    advice: list[str] = []
    summary: str | None = None
    started_at: datetime
    ended_at: datetime | None = None
    status: str


class PoseFramePreview(BaseModel):
    frame_id: str
    timestamp_ms: int
    score: int


class SessionDetail(SessionSummary):
    frames: list[PoseFramePreview] = []


class PoseFramePayload(BaseModel):
    frame_id: str | None = None
    timestamp_ms: int = Field(ge=0)
    pose_landmarks: list[PoseLandmark]
    media_path: str | None = None


class PoseInferenceResult(BaseModel):
    session_id: str
    frame_id: str
    score: int
    advice: list[str]
    summary: str
    confidence: float
    pose_service_latency_ms: int
