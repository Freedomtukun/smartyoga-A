from datetime import datetime, timedelta

from ..core.config import get_settings
from ..db.fake import get_db


def purge_expired_sessions() -> int:
    settings = get_settings()
    cutoff = datetime.utcnow() - timedelta(days=settings.pipeda_retention_days)
    db = get_db()
    to_delete = [sid for sid, session in db.sessions.items() if session.ended_at and session.ended_at < cutoff]
    for sid in to_delete:
        db.sessions.pop(sid, None)
    return len(to_delete)
