from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os, time, httpx

POSE_URL = os.getenv("POSE_URL", "http://localhost:8081")
API_PORT = int(os.getenv("API_PORT", "8080"))

app = FastAPI(title="SmartYoga API")

def ok(data): return {"ok": True, "data": data}

class ScoreIn(BaseModel):
    image_base64: str | None = None
    image_url: str | None = None
    poseId: str | None = "tree_pose"

@app.get("/health")
def health():
    return ok({"ts": int(time.time()*1000), "pose": POSE_URL})

@app.post("/pose/score")
async def pose_score(inp: ScoreIn):
    if not (inp.image_base64 or inp.image_url):
        raise HTTPException(400, detail={"ok": False, "error": {"code":"INVALID_INPUT","message":"image_base64 or image_url required"}})
    async with httpx.AsyncClient(timeout=20.0) as cli:
        r = await cli.post(f"{POSE_URL}/score", json=inp.model_dump())
        r.raise_for_status()
        return ok(r.json())

class TTSIn(BaseModel):
    text: str

@app.post("/tts/say")
async def tts_say(inp: TTSIn):
    # 占位实现：返回固定 mp3 地址（后续接 Piper/Coqui）
    # 你也可以把一个短 mp3 文件放到 GCS 或静态托管上，这里先返回可测的占位 URL
    return ok({"audioUrl": "https://file-examples.com/storage/fe7b1f23a4c0a67e0c2f59b/2017/11/file_example_MP3_700KB.mp3"})
