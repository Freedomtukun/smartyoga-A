from __future__ import annotations

import asyncio
import json
from datetime import datetime
from typing import Any, Dict

import redis.asyncio as redis

from ..core.config import get_settings


class AnalyticsService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self._redis: redis.Redis | None = None

    async def _client(self) -> redis.Redis:
        if self._redis is None:
            self._redis = redis.from_url(self.settings.redis_url)
        return self._redis

    async def publish_event(self, event: Dict[str, Any]) -> str:
        batch_id = f"evt_{int(datetime.utcnow().timestamp())}"
        payload = json.dumps({"batch_id": batch_id, "event": event})
        try:
            client = await self._client()
            await client.lpush("analytics_events", payload)
            await client.expire("analytics_events", 3600)
        except Exception:
            # tolerate missing Redis during local dev
            pass
        return batch_id

    async def close(self) -> None:
        if self._redis is not None:
            await self._redis.aclose()
            self._redis = None


analytics_service = AnalyticsService()
