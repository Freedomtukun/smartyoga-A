from __future__ import annotations

from datetime import datetime, timedelta
from typing import Tuple

import stripe

from ..core.config import get_settings


class BillingService:
    def __init__(self) -> None:
        self.settings = get_settings()
        stripe.api_key = self.settings.stripe_secret_key

    def create_checkout_session(self, user_id: str, plan_id: str, success_url: str, cancel_url: str) -> Tuple[str, str, datetime]:
        if not self.settings.stripe_price_id_premium:
            # Fallback stub for local dev
            session_id = f"cs_test_{user_id}"
            checkout_url = f"https://checkout.stripe.com/pay/{session_id}"
            return checkout_url, session_id, datetime.utcnow() + timedelta(minutes=30)
        session = stripe.checkout.Session.create(
            line_items=[{"price": self.settings.stripe_price_id_premium, "quantity": 1}],
            mode="subscription",
            success_url=success_url,
            cancel_url=cancel_url,
            client_reference_id=user_id,
        )
        expires = datetime.fromtimestamp(session.expires_at) if session.expires_at else datetime.utcnow() + timedelta(minutes=30)
        return session.url, session.id, expires


billing_service = BillingService()
