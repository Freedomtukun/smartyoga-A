from __future__ import annotations

import logging
from typing import Any, Dict

import httpx

from ..core.config import get_settings

logger = logging.getLogger(__name__)


class TTSClient:
    def __init__(self) -> None:
        self.settings = get_settings()
        self._client = httpx.AsyncClient(timeout=10.0)

    async def synthesize(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        urls = [self.settings.tts_service_url]
        if not self.settings.local_first:
            urls.reverse()
        urls.append(self.settings.tts_remote_url)

        last_error: Exception | None = None
        for url in urls:
            try:
                response = await self._client.post(f"{url}/v1/tts/speak", json=payload)
                response.raise_for_status()
                return response.json()
            except Exception as exc:  # pragma: no cover simple network wrapper
                last_error = exc
                logger.warning("TTS service call failed", exc_info=exc)
        raise RuntimeError("TTSUnavailable") from last_error


tts_client = TTSClient()
