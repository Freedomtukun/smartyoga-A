from __future__ import annotations

import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from ..core.security import hash_password


@dataclass
class User:
    user_id: str
    email: str
    password_hash: str
    display_name: str
    locale: str
    membership_tier: str = "free"
    stripe_customer_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Session:
    session_id: str
    user_id: str
    pose_profile: str
    notes: str | None
    started_at: datetime
    status: str = "active"
    ended_at: Optional[datetime] = None
    score: Optional[int] = None
    advice: list[str] = field(default_factory=list)
    summary: Optional[str] = None


@dataclass
class Frame:
    frame_id: str
    session_id: str
    timestamp_ms: int
    score: int
    advice: list[str]
    summary: str
    confidence: float
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Membership:
    membership_id: str
    user_id: str
    status: str
    plan_id: str
    current_period_end: datetime
    stripe_subscription_id: Optional[str] = None


@dataclass
class RefreshToken:
    token_id: str
    user_id: str
    hashed_token: str
    expires_at: datetime


class FakeDatabase:
    def __init__(self) -> None:
        self.users: Dict[str, User] = {}
        self.users_by_email: Dict[str, str] = {}
        self.sessions: Dict[str, Session] = {}
        self.frames: Dict[str, Frame] = {}
        self.memberships: Dict[str, Membership] = {}
        self.tokens: Dict[str, RefreshToken] = {}

    def create_user(self, email: str, password: str, display_name: str, locale: str) -> User:
        if email in self.users_by_email:
            raise ValueError("EmailExists")
        user_id = f"usr_{secrets.token_hex(6)}"
        user = User(user_id=user_id, email=email, password_hash=hash_password(password), display_name=display_name, locale=locale)
        self.users[user_id] = user
        self.users_by_email[email] = user_id
        return user

    def get_user_by_email(self, email: str) -> Optional[User]:
        user_id = self.users_by_email.get(email)
        if not user_id:
            return None
        return self.users.get(user_id)

    def get_user(self, user_id: str) -> Optional[User]:
        return self.users.get(user_id)

    def update_user(self, user_id: str, **fields: Any) -> Optional[User]:
        user = self.users.get(user_id)
        if not user:
            return None
        for key, value in fields.items():
            if value is not None and hasattr(user, key):
                setattr(user, key, value)
        user.updated_at = datetime.utcnow()
        return user

    def create_session(self, user_id: str, pose_profile: str, notes: Optional[str]) -> Session:
        session_id = f"ses_{secrets.token_hex(6)}"
        session = Session(session_id=session_id, user_id=user_id, pose_profile=pose_profile, notes=notes, started_at=datetime.utcnow())
        self.sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        return self.sessions.get(session_id)

    def add_frame(self, session_id: str, score: int, advice: list[str], summary: str, confidence: float, timestamp_ms: int, frame_id: str | None = None) -> Frame:
        frame_id = frame_id or f"frm_{secrets.token_hex(6)}"
        frame = Frame(frame_id=frame_id, session_id=session_id, timestamp_ms=timestamp_ms, score=score, advice=advice, summary=summary, confidence=confidence)
        self.frames[frame.frame_id] = frame
        session = self.sessions[session_id]
        session.score = score
        session.advice = advice
        session.summary = summary
        return frame

    def create_refresh_token(self, user_id: str, hashed_token: str, expires_in_minutes: int = 60 * 24 * 7) -> RefreshToken:
        token_id = f"tok_{secrets.token_hex(6)}"
        refresh_token = RefreshToken(token_id=token_id, user_id=user_id, hashed_token=hashed_token, expires_at=datetime.utcnow() + timedelta(minutes=expires_in_minutes))
        self.tokens[token_id] = refresh_token
        return refresh_token

    def get_refresh_token(self, token_id: str) -> Optional[RefreshToken]:
        return self.tokens.get(token_id)


db = FakeDatabase()


def get_db() -> FakeDatabase:
    return db
