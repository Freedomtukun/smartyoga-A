from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', case_sensitive=False)

    app_name: str = "SmartYoga API"
    app_env: str = "development"
    log_level: str = "info"

    fastapi_host: str = "0.0.0.0"
    fastapi_port: int = 8000
    fastapi_secret_key: str = "change_me"

    database_url: str = "sqlite+aiosqlite:///./tmp.db"
    redis_url: str = "redis://localhost:6379/0"

    pose_service_url: str = "http://localhost:8501"
    pose_remote_url: str = "https://pose-backup.smartyoga.ca"
    tts_service_url: str = "http://localhost:8601"
    tts_remote_url: str = "https://tts-backup.smartyoga.ca"
    local_first: bool = True

    stripe_public_key: str = ""
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_price_id_premium: str = ""

    pipeda_retention_days: int = 365
    media_storage_bucket: str = "gs://smartyoga-media"
    media_cdn_base: str = "https://cdn.smartyoga.ca"


@lru_cache
def get_settings() -> Settings:
    return Settings()
