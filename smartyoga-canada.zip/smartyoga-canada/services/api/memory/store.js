import { FieldValue } from "@google-cloud/firestore";
import firestore from "../lib/firestore.js";

const MEMORY_COLLECTION = "user_memories";
const ENTRY_SUBCOLLECTION = "entries";

const serverTimestamp = () => FieldValue.serverTimestamp();

export async function getUserMemory(userId) {
  const docRef = firestore.collection(MEMORY_COLLECTION).doc(userId);
  const snapshot = await docRef.get();
  if (!snapshot.exists) {
    const placeholder = buildInitialMemoryDocument(userId);
    await docRef.set(placeholder);
    const created = await docRef.get();
    return { userId, ...(created.data() || {}) };
  }
  return { userId, ...(snapshot.data() || {}) };
}

export async function upsertUserMemory(userId, payload) {
  const docRef = firestore.collection(MEMORY_COLLECTION).doc(userId);
  const data = normalizeMemoryUpdate(payload);
  await docRef.set({ ...data, updatedAt: serverTimestamp() }, { merge: true });
  const snapshot = await docRef.get();
  return { userId, ...(snapshot.data() || {}) };
}

export async function listMemoryEntries(userId, { limit = 20, order = "desc" } = {}) {
  const collectionRef = firestore
    .collection(MEMORY_COLLECTION)
    .doc(userId)
    .collection(ENTRY_SUBCOLLECTION)
    .orderBy("createdAt", order === "asc" ? "asc" : "desc")
    .limit(limit);
  const snapshot = await collectionRef.get();
  return snapshot.docs.map((doc) => ({ entryId: doc.id, ...(doc.data() || {}) }));
}

export async function addMemoryEntry(userId, entry) {
  const normalized = normalizeMemoryEntry(entry);
  const entriesRef = firestore.collection(MEMORY_COLLECTION).doc(userId).collection(ENTRY_SUBCOLLECTION);
  const docRef = await entriesRef.add(normalized);
  await updateMemorySummaryFields(userId, normalized);
  const stored = await docRef.get();
  return { entryId: docRef.id, ...(stored.data() || {}) };
}

function buildInitialMemoryDocument(userId) {
  const now = serverTimestamp();
  return {
    userId,
    createdAt: now,
    updatedAt: now,
    profile: {
      displayName: null,
      locale: null,
      goals: [],
      preferredPersona: "nova",
      ttsVoice: null,
    },
    preferences: {
      language: null,
      reminders: {
        enabled: false,
        cadence: null,
      },
    },
    stats: {
      sessionsCompleted: 0,
      averageScore: null,
      lastSessionAt: null,
    },
    summary: {
      text: null,
      updatedAt: now,
      tokens: 0,
    },
    lastEntryPreview: null,
  };
}

function normalizeMemoryUpdate(payload = {}) {
  const data = {};
  if (payload.profile) {
    data.profile = {
      displayName: payload.profile.displayName ?? null,
      locale: payload.profile.locale ?? null,
      goals: Array.isArray(payload.profile.goals) ? payload.profile.goals.slice(0, 10) : [],
      preferredPersona: payload.profile.preferredPersona ?? "nova",
      ttsVoice: payload.profile.ttsVoice ?? null,
    };
  }
  if (payload.preferences) {
    data.preferences = {
      language: payload.preferences.language ?? null,
      reminders: {
        enabled: Boolean(payload.preferences?.reminders?.enabled),
        cadence: payload.preferences?.reminders?.cadence ?? null,
      },
    };
  }
  if (payload.stats) {
    data.stats = {
      sessionsCompleted: Number.isFinite(payload.stats.sessionsCompleted)
        ? payload.stats.sessionsCompleted
        : 0,
      averageScore: Number.isFinite(payload.stats.averageScore) ? payload.stats.averageScore : null,
      lastSessionAt: payload.stats.lastSessionAt ?? null,
    };
  }
  if (payload.summary) {
    data.summary = {
      text: payload.summary.text ?? null,
      updatedAt: serverTimestamp(),
      tokens: Number.isFinite(payload.summary.tokens) ? payload.summary.tokens : 0,
    };
  }
  if (payload.lastEntryPreview) {
    data.lastEntryPreview = {
      type: payload.lastEntryPreview.type ?? null,
      content: payload.lastEntryPreview.content ?? null,
      createdAt: serverTimestamp(),
    };
  }
  return data;
}

function normalizeMemoryEntry(entry = {}) {
  const now = serverTimestamp();
  return {
    type: entry.type ?? "note",
    source: entry.source ?? "manual",
    content: entry.content ?? "",
    summary: entry.summary ?? null,
    tags: Array.isArray(entry.tags) ? entry.tags.slice(0, 8) : [],
    score: Number.isFinite(entry.score) ? entry.score : null,
    metadata: entry.metadata ?? {},
    createdAt: now,
  };
}

async function updateMemorySummaryFields(userId, entry) {
  const docRef = firestore.collection(MEMORY_COLLECTION).doc(userId);
  await docRef.set(
    {
      lastEntryPreview: {
        type: entry.type,
        content: entry.content?.slice?.(0, 240) ?? null,
        createdAt: serverTimestamp(),
      },
      updatedAt: serverTimestamp(),
    },
    { merge: true },
  );
}

export async function recordPoseSample(userId, sample = {}) {
  if (!userId) return;
  const docRef = firestore.collection(MEMORY_COLLECTION).doc(userId);
  await firestore.runTransaction(async (tx) => {
    const snapshot = await tx.get(docRef);
    if (!snapshot.exists) {
      tx.set(docRef, buildInitialMemoryDocument(userId));
    }
    const data = snapshot.exists ? snapshot.data() || {} : {};
    const stats = data.stats || {};
    const poseSamples = stats.poseSamples || {
      count: 0,
      averageScore: 0,
      symmetryAvg: 0,
      verticalityAvg: 0,
      extensionAvg: 0,
    };

    const score = Number.isFinite(sample.score) ? sample.score : 0;
    const symmetry = Number.isFinite(sample.metrics?.symmetry) ? sample.metrics.symmetry : null;
    const verticality = Number.isFinite(sample.metrics?.verticality) ? sample.metrics.verticality : null;
    const extension = Number.isFinite(sample.metrics?.extension) ? sample.metrics.extension : null;

    const prevCount = poseSamples.count || 0;
    const newCount = prevCount + 1;

    const rollingAverage = (prev, value) => {
      if (!Number.isFinite(value)) return prev;
      return ((prev * prevCount) + value) / newCount;
    };

    const updatedPoseSamples = {
      count: newCount,
      averageScore: Number(rollingAverage(poseSamples.averageScore || 0, score).toFixed(2)),
      symmetryAvg: Number(rollingAverage(poseSamples.symmetryAvg || 0, symmetry ?? poseSamples.symmetryAvg || 0).toFixed(3)),
      verticalityAvg: Number(rollingAverage(poseSamples.verticalityAvg || 0, verticality ?? poseSamples.verticalityAvg || 0).toFixed(3)),
      extensionAvg: Number(rollingAverage(poseSamples.extensionAvg || 0, extension ?? poseSamples.extensionAvg || 0).toFixed(3)),
      lastScore: score,
      lastPoseId: sample.poseId ?? null,
      updatedAt: serverTimestamp(),
    };

    const totalSessions = (stats.sessionsCompleted || 0) + 1;
    const avgScore = stats.averageScore
      ? ((stats.averageScore || 0) * (stats.sessionsCompleted || 0) + score) / totalSessions
      : score;

    const updatedStats = {
      ...stats,
      sessionsCompleted: totalSessions,
      averageScore: Number(avgScore.toFixed(2)),
      lastSessionAt: serverTimestamp(),
      poseSamples: updatedPoseSamples,
    };

    const adaptive = computeAdaptiveThresholdsFromStats(updatedPoseSamples);
    const mergedPreferences = {
      ...(data.preferences || {}),
      poseThresholds: adaptive || data.preferences?.poseThresholds || null,
    };

    tx.set(docRef, {
      stats: updatedStats,
      preferences: mergedPreferences,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  });
}

export function resolveAdaptiveThresholds(memoryDoc) {
  if (!memoryDoc) return null;
  if (memoryDoc.preferences?.poseThresholds) {
    return memoryDoc.preferences.poseThresholds;
  }
  if (memoryDoc.stats?.poseSamples) {
    return computeAdaptiveThresholdsFromStats(memoryDoc.stats.poseSamples);
  }
  return null;
}

function computeAdaptiveThresholdsFromStats(stats = {}) {
  if (!stats.count || stats.count < 5) return null;
  const base = {
    minConf: 0.35,
    tolSym: 0.18,
    tolVert: 35,
    extRef: 1.2,
  };

  const symmetryAvg = clamp(Number(stats.symmetryAvg ?? 0.8), 0.4, 1);
  const verticalityAvg = clamp(Number(stats.verticalityAvg ?? 0.8), 0.4, 1);
  const extensionAvg = clamp(Number(stats.extensionAvg ?? 0.8), 0.4, 1.4);
  const scoreAvg = clamp(Number(stats.averageScore ?? 70) / 100, 0, 1);

  base.tolSym = clamp(base.tolSym - (symmetryAvg - 0.75) * 0.05, 0.12, 0.24);
  base.tolVert = clamp(base.tolVert - (verticalityAvg - 0.75) * 8, 24, 42);
  base.extRef = clamp(base.extRef + (extensionAvg - 0.85) * 0.2, 0.9, 1.5);
  base.minConf = clamp(base.minConf + (scoreAvg - 0.7) * 0.08, 0.3, 0.55);

  return {
    ...base,
    updatedAt: stats.updatedAt ?? null,
    sampleCount: stats.count,
  };
}

function clamp(value, minValue, maxValue) {
  return Math.max(minValue, Math.min(maxValue, value));
}

export default {
  getUserMemory,
  upsertUserMemory,
  listMemoryEntries,
  addMemoryEntry,
  recordPoseSample,
  resolveAdaptiveThresholds,
};
