import { randomUUID } from "crypto";

import { buildSystemPrompt, resolvePersona } from "../grok/prompt.js";
import { getUserMemory } from "../memory/store.js";

const MAX_AUDIO_BUFFER_BYTES = 1_500_000; // ~1.5MB safety guard

export async function setupRealtimeServer({ server, log, port, sttUrl, ttsUrl, defaultVoice }) {
  let WebSocketServer;
  try {
    ({ WebSocketServer } = await import("ws"));
  } catch (err) {
    log.warn({ err }, "ws package not installed; realtime channel disabled");
    return;
  }

  const wss = new WebSocketServer({ server, path: "/realtime" });
  log.info({ path: "/realtime" }, "Realtime WebSocket server initialised");

  wss.on("connection", (socket, request) => {
    const session = new RealtimeSession({ socket, request, log, port, sttUrl, ttsUrl, defaultVoice });
    session.bootstrap().catch((err) => {
      session.logger.error({ err }, "session bootstrap failed");
      session.close(1011, "bootstrap_failed");
    });
  });
}

class RealtimeSession {
  constructor({ socket, request, log, port, sttUrl, ttsUrl, defaultVoice }) {
    this.id = randomUUID();
    this.socket = socket;
    this.request = request;
    this.logger = log.child({ scope: "realtime", sessionId: this.id });
    this.port = port;
    this.sttUrl = sttUrl;
    this.ttsUrl = ttsUrl;
    this.defaultVoice = defaultVoice || "alloy";

    this.initialised = false;
    this.closed = false;

    this.userId = null;
    this.persona = resolvePersona();
    this.locale = this.persona.defaultLocale;
    this.memoryDoc = null;
    this.conversation = [];
    this.bufferedAudio = [];
    this.voiceId = this.defaultVoice;

    this.socket.on("close", (code, reason) => {
      this.closed = true;
      this.logger.info({ code, reason: reason?.toString?.() }, "session closed");
    });
    this.socket.on("error", (err) => {
      this.logger.warn({ err }, "socket error");
    });
  }

  async bootstrap() {
    this.socket.on("message", (data, isBinary) => {
      this.handleMessage(data, isBinary).catch((err) => {
        this.logger.error({ err }, "message handling failed");
        this.close(1011, "message_error");
      });
    });
    this.logger.info("session connected");
  }

  async handleMessage(data, isBinary) {
    if (this.closed) return;
    if (!this.initialised) {
      await this.handleHello(data, isBinary);
      return;
    }

    if (isBinary || Buffer.isBuffer(data)) {
      await this.handleAudioChunk(Buffer.from(data));
      return;
    }

    let payload;
    try {
      payload = JSON.parse(typeof data === "string" ? data : data.toString());
    } catch (err) {
      this.logger.warn({ err }, "invalid json payload");
      this.send({ type: "error", code: "invalid_json" });
      return;
    }

    switch (payload?.type) {
      case "user.text":
        if (payload.text) {
          await this.handleUserText(payload.text, payload.metadata || {});
        }
        break;
      case "audio.commit":
        await this.commitAudio(payload || {});
        break;
      case "ping":
        this.send({ type: "pong", ts: Date.now() });
        break;
      default:
        this.logger.warn({ payload }, "unhandled message type");
        this.send({ type: "error", code: "unsupported", detail: payload?.type });
    }
  }

  async handleHello(data, isBinary) {
    if (isBinary) {
      this.send({ type: "error", code: "handshake_required" });
      this.close(1002, "handshake_binary");
      return;
    }
    let payload;
    try {
      payload = JSON.parse(typeof data === "string" ? data : data.toString());
    } catch (err) {
      this.logger.warn({ err }, "failed to parse handshake payload");
      this.send({ type: "error", code: "invalid_hello" });
      this.close(1002, "invalid_handshake");
      return;
    }

    if (payload?.type !== "hello") {
      this.send({ type: "error", code: "hello_expected" });
      this.close(1002, "hello_expected");
      return;
    }

    this.userId = payload.userId || null;
    this.persona = resolvePersona(payload.persona || payload.preferredPersona);
    this.locale = payload.locale || this.persona.defaultLocale;

    if (this.userId) {
      try {
        this.memoryDoc = await getUserMemory(this.userId);
      } catch (err) {
        this.logger.warn({ err }, "failed to load memory");
      }
    }

    this.voiceId =
      payload.voiceId
      || payload.preferredVoice
      || this.memoryDoc?.profile?.ttsVoice
      || this.defaultVoice;

    const memorySummary = this.memoryDoc?.summary?.text || null;
    const sessionGoal = Array.isArray(this.memoryDoc?.profile?.goals) && this.memoryDoc.profile.goals.length
      ? this.memoryDoc.profile.goals[0]
      : null;

    const systemPrompt = buildSystemPrompt({
      persona: this.persona,
      locale: this.locale,
      memorySummary,
      sessionGoal,
    });
    this.conversation = [{ role: "system", content: systemPrompt }];
    this.initialised = true;

    this.send({
      type: "ready",
      sessionId: this.id,
      persona: this.persona.id,
      locale: this.locale,
      voiceId: this.voiceId,
      audio: {
        enabled: Boolean(this.ttsUrl),
      },
      memory: this.serializeMemoryPreview(this.memoryDoc),
    });
  }

  async handleAudioChunk(chunk) {
    if (!chunk || !chunk.length) return;
    if (this.totalAudioSize() + chunk.length > MAX_AUDIO_BUFFER_BYTES) {
      this.logger.warn({ bytes: chunk.length }, "audio buffer overflow");
      this.bufferedAudio = [];
      this.send({ type: "error", code: "audio_buffer_overflow" });
      return;
    }
    this.bufferedAudio.push(chunk);
    this.send({ type: "ack", bytes: chunk.length });
  }

  totalAudioSize() {
    return this.bufferedAudio.reduce((sum, buf) => sum + buf.length, 0);
  }

  async commitAudio(payload) {
    if (!this.bufferedAudio.length) {
      this.logger.debug("audio commit with empty buffer");
      return;
    }
    const combined = Buffer.concat(this.bufferedAudio);
    this.bufferedAudio = [];

    const transcript = await this.transcribeAudio(combined, payload || {});
    if (!transcript) {
      return;
    }

    this.send({ type: "transcript", text: transcript, isFinal: true });
    await this.handleUserText(transcript, { origin: "stt" });
  }

  async transcribeAudio(buffer, payload) {
    if (!buffer || !buffer.length) return null;
    if (!this.sttUrl) {
      this.logger.debug("stt url missing, returning stub transcript");
      return `[audio ${buffer.length} bytes]`;
    }
    try {
      const resp = await fetch(new URL("/v1/stt/transcribe", this.sttUrl), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          encoding: payload.encoding || "pcm16",
          sampleRate: payload.sampleRate || 16000,
          audioBase64: buffer.toString("base64"),
        }),
      });
      if (!resp.ok) {
        const errBody = await resp.text();
        this.logger.warn({ status: resp.status, body: errBody }, "stt service error");
        return null;
      }
      const json = await resp.json();
      return json?.text || json?.transcript || null;
    } catch (err) {
      this.logger.warn({ err }, "stt request failed");
      return null;
    }
  }

  async handleUserText(text, metadata) {
    const trimmed = typeof text === "string" ? text.trim() : "";
    if (!trimmed) return;

    this.conversation.push({ role: "user", content: trimmed });
    this.send({ type: "user_ack", text: trimmed, metadata });

    try {
      const chatResponse = await this.invokeChatApi(trimmed);
      if (!chatResponse?.ok) {
        this.send({ type: "error", code: "chat_failed", detail: chatResponse?.error });
        return;
      }
      const data = chatResponse.data;
      if (data?.reply) {
        this.conversation.push({ role: "assistant", content: data.reply });
        this.send({
          type: "assistant.reply",
          reply: data.reply,
          persona: data.persona,
          locale: data.locale,
          audio: data.audio || null,
          toolInvocations: data.toolInvocations || [],
          usage: data.usage || null,
          provider: data.provider || null,
          guardrails: data.guardrails || null,
        });
      }
    } catch (err) {
      this.logger.error({ err }, "chat invocation failed");
      this.send({ type: "error", code: "chat_exception" });
    }
  }

  async invokeChatApi(latestUserText) {
    const body = {
      messages: this.conversation.filter((msg) => msg.role !== "system"),
      persona: this.persona.id,
      locale: this.locale,
      includeAudio: Boolean(this.ttsUrl),
      voiceId: this.voiceId,
      context: {
        userId: this.userId,
        sessionId: this.id,
        origin: "realtime",
        persistMemory: false,
        latestUserText,
        includeAudio: Boolean(this.ttsUrl),
      },
    };
    try {
      const resp = await fetch(`http://127.0.0.1:${this.port}/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!resp.ok) {
        const detail = await resp.text();
        this.logger.warn({ status: resp.status, detail }, "chat endpoint error");
        return { ok: false, error: `status_${resp.status}` };
      }
      return resp.json();
    } catch (err) {
      this.logger.error({ err }, "failed to call chat endpoint");
      return { ok: false, error: err.message };
    }
  }

  serializeMemoryPreview(memoryDoc) {
    if (!memoryDoc) return null;
    return {
      summary: memoryDoc.summary?.text ?? null,
      profile: memoryDoc.profile || null,
      lastEntryPreview: memoryDoc.lastEntryPreview || null,
    };
  }

  send(payload) {
    if (this.closed) return;
    try {
      this.socket.send(JSON.stringify(payload));
    } catch (err) {
      this.logger.warn({ err }, "failed to send frame");
    }
  }

  close(code, reason) {
    if (this.closed) return;
    this.closed = true;
    try {
      this.socket.close(code, reason);
    } catch (err) {
      this.logger.warn({ err }, "error closing socket");
    }
  }
}

export default setupRealtimeServer;
