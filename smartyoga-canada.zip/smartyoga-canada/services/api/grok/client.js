const DEFAULT_BASE_URL = "https://api.x.ai";
const DEFAULT_MODEL = "grok-4-fast-reasoning";

export class GrokClient {
  constructor({ apiKey, baseUrl, model, fetchImpl, log }) {
    this.apiKey = apiKey;
    this.baseUrl = (baseUrl || DEFAULT_BASE_URL).replace(/\/?$/, "");
    this.model = model || DEFAULT_MODEL;
    this.fetch = fetchImpl;
    this.log = log;
  }

  get isEnabled() {
    return Boolean(this.apiKey) && typeof this.fetch === "function";
  }

  async chat({ messages, tools, toolChoice = "auto", temperature = 0.7, maxOutputTokens, responseFormat }) {
    if (!this.isEnabled) {
      throw new Error("GrokClientDisabled");
    }

    const endpoint = `${this.baseUrl}/v1/chat/completions`;
    const payload = {
      model: this.model,
      messages,
      temperature,
      tool_choice: toolChoice,
    };
    if (Array.isArray(tools) && tools.length) {
      payload.tools = tools;
    }
    if (Number.isFinite(maxOutputTokens)) {
      payload.max_output_tokens = maxOutputTokens;
    }
    if (responseFormat) {
      payload.response_format = responseFormat;
    }

    const res = await this.fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      let detail;
      try {
        detail = await res.json();
      } catch (err) {
        detail = { message: res.statusText };
      }
      const error = new Error(`GrokClientError: ${detail?.message ?? res.statusText}`);
      error.status = res.status;
      error.detail = detail;
      throw error;
    }

    return res.json();
  }
}

export default GrokClient;
