export const PERSONA_REGISTRY = {
  nova: {
    id: "nova",
    displayName: "Coach Nova",
    description: "a calm, encouraging SmartYoga coach with evidence-based guidance",
    defaultLocale: "en-CA",
    speakingStyle: "warm, encouraging, gently precise",
    ttsVoice: "en-CA-Standard-A",
    defaultLanguage: "English (Canada)",
    keywords: ["alignment", "breath", "compassion"],
  },
  aurora: {
    id: "aurora",
    displayName: "Coach Aurora",
    description: "bilingual mentor fluent in English and French with upbeat studio energy",
    defaultLocale: "fr-CA",
    speakingStyle: "upbeat, energetic, practical",
    ttsVoice: "fr-CA-Standard-C",
    defaultLanguage: "Français (Canada)",
    keywords: ["motivation", "cadence", "flow"],
  },
  mingxia: {
    id: "mingxia",
    displayName: "教练明霞",
    description: "温柔的中文教练，擅长缓解压力与身心调和",
    defaultLocale: "zh-CN",
    speakingStyle: "柔和、细腻、富有画面感",
    ttsVoice: "zh-CN-Standard-A",
    defaultLanguage: "简体中文",
    keywords: ["放松", "呼吸", "肩颈"],
  },
};

export function resolvePersona(personaId) {
  if (!personaId) return PERSONA_REGISTRY.nova;
  return PERSONA_REGISTRY[personaId] || PERSONA_REGISTRY.nova;
}
