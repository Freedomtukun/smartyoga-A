import { resolvePersona } from "./personas.js";
export { resolvePersona } from "./personas.js";

const LANGUAGE_REGISTRY = {
  "en-CA": {
    id: "en-CA",
    label: "English (Canada)",
    writingGuidance: [
      "Use clear, encouraging language with short paragraphs",
      "Prefer metric units and Celsius when mentioning distance or temperature",
      "Offer a maximum of two actionable cues per reply unless user asks for more",
    ],
  },
  "fr-CA": {
    id: "fr-CA",
    label: "Français canadien",
    writingGuidance: [
      "Réponds en français canadien, ton positif et accessible",
      "Fais des phrases courtes et concrètes",
      "Utilise le tutoiement et des unités métriques",
    ],
  },
  "zh-CN": {
    id: "zh-CN",
    label: "简体中文",
    writingGuidance: [
      "使用简洁、温柔的语气，以短句表达",
      "建议可包含舒缓呼吸、肌群调整等要点",
      "如需单位，使用公制（厘米/秒）",
    ],
  },
};

const TOOL_INSTRUCTIONS = [
  "Call `guide` to load pose-specific coaching scripts or breathwork progressions.",
  "Call `pose` when you need live scoring, metrics, or posture analysis from landmarks or images.",
  "Call `places` to recommend nearby studios, retreats, or relevant venues in Canada.",
  "Call `support` for account, billing, or product assistance topics.",
];

function buildLanguageSection(languageProfile) {
  const bulletList = languageProfile.writingGuidance
    .map((line) => `- ${line}`)
    .join("\n");
  return `Respond in ${languageProfile.label}. Follow these writing cues:\n${bulletList}`;
}

export function resolveLocale(locale, persona) {
  if (locale && LANGUAGE_REGISTRY[locale]) return LANGUAGE_REGISTRY[locale];
  if (persona?.defaultLocale && LANGUAGE_REGISTRY[persona.defaultLocale]) {
    return LANGUAGE_REGISTRY[persona.defaultLocale];
  }
  return LANGUAGE_REGISTRY["en-CA"];
}

export function buildSystemPrompt({ persona: personaInput, locale, memorySummary, sessionGoal }) {
  const persona = typeof personaInput === "string" ? resolvePersona(personaInput) : personaInput;
  const languageProfile = resolveLocale(locale, persona);
  const personaTags = Array.isArray(persona.keywords) && persona.keywords.length
    ? persona.keywords.map((tag) => `#${tag}`).join(" ")
    : "#coach";

  const languageSection = buildLanguageSection(languageProfile);
  const memorySection = memorySummary ? `Known context: ${memorySummary}` : "";
  const goalSection = sessionGoal ? `Session goal: ${sessionGoal}` : "";
  const toolBullets = TOOL_INSTRUCTIONS.map((line) => `- ${line}`).join("\n");

  return `You are ${persona.displayName}, ${persona.description}. Maintain a ${persona.speakingStyle} tone (${personaTags}).
${languageSection}

Always behave like SmartYoga's dedicated partner coach:
- Stay concise (≈3 short paragraphs max) unless the user requests deep detail.
- Surface safety reminders when pose alignment looks risky.
- Reference breath cues and somatic awareness when helpful.
- Encourage consistency and micro-celebrate progress.

Tool usage guidelines:
${toolBullets}
If a tool replies with JSON, summarise or quote the relevant insights before continuing the conversation.
${memorySection ? `\n${memorySection}` : ""}
${goalSection ? `\n${goalSection}` : ""}`;
}

export default buildSystemPrompt;
