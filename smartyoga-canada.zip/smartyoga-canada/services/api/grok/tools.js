import { genericScore } from "../lib/poseMetrics.js";

const POSE_GUIDES = {
  tree_pose: {
    id: "tree_pose",
    translations: {
      "en-CA": {
        name: "Tree Pose",
        steps: [
          "Shift weight into your standing leg and root through the heel.",
          "Place the opposite foot on the inner calf or thigh (avoid the knee joint).",
          "Lengthen through the crown, soften the ribs, and engage the core.",
        ],
        cues: [
          "Think 'hip points forward' to avoid opening the pelvis.",
          "Press foot and leg together for stability.",
        ],
        breath: "Inhale to lengthen, exhale to soften shoulders.",
      },
      "fr-CA": {
        name: "Posture de l'arbre",
        steps: [
          "Ancre ton pied dans le sol et engage la jambe d'appui.",
          "Place l'autre pied sur le mollet ou la cuisse, jamais sur le genou.",
          "Allonge la colonne et garde les épaules détendues.",
        ],
        cues: [
          "Pense à garder les hanches parallèles à l'avant.",
          "Presse la jambe et le pied l'un contre l'autre.",
        ],
        breath: "Inspire pour t'allonger, expire pour relâcher les épaules.",
      },
      "zh-CN": {
        name: "树式",
        steps: [
          "站立腿扎根脚跟，感受脚底与地面的连接。",
          "另一只脚放在小腿或大腿内侧，避开膝关节。",
          "延展脊柱，轻收肋骨，保持核心稳定。",
        ],
        cues: [
          "想象髋部朝向正前方，避免外旋。",
          "脚与腿内侧互相按压，提升稳定感。",
        ],
        breath: "吸气向上延展，呼气软化肩颈。",
      },
    },
    focusTips: {
      balance: "Use a fixed drishti (gaze point) to anchor balance.",
      grounding: "Spread toes and lift arches to ground evenly.",
      hips: "Draw the lifted knee back only as far as hips stay level.",
    },
    durationSeconds: 60,
  },
  warrior_ii: {
    id: "warrior_ii",
    translations: {
      "en-CA": {
        name: "Warrior II",
        steps: [
          "Step feet wide, front toes forward, back foot slightly in.",
          "Bend front knee over ankle while pressing outer edge of back foot.",
          "Reach arms long, shoulders soft, gaze over front hand.",
        ],
        cues: [
          "Keep front knee tracking over second toe.",
          "Lift through the back thigh and belly.",
        ],
        breath: "Inhale widen ribcage, exhale ground through both legs.",
      },
      "fr-CA": {
        name: "Guerrier II",
        steps: [
          "Écarte les pieds, pied avant vers l'avant, pied arrière légèrement rentré.",
          "Plie le genou avant au-dessus de la cheville, presse le bord externe du pied arrière.",
          "Allonge les bras, détends les épaules, regarde devant.",
        ],
        cues: [
          "Genou avant aligné avec le deuxième orteil.",
          "Soulève la cuisse arrière et le bas-ventre.",
        ],
        breath: "Inspire pour élargir, expire pour t'ancrer.",
      },
      "zh-CN": {
        name: "战士二式",
        steps: [
          "双脚分开，前脚朝前，后脚稍内扣。",
          "弯曲前膝至脚踝正上方，后脚外侧边缘压向地面。",
          "两臂展开，肩膀放松，目光越过前手。",
        ],
        cues: [
          "前膝跟第二脚趾方向一致。",
          "提起后腿和下腹，保持力量。",
        ],
        breath: "吸气扩展胸腔，呼气扎根双腿。",
      },
    },
    focusTips: {
      stamina: "Let breath cadence set the rhythm for endurance.",
      hips: "Soften front hip crease so the pelvis stays level.",
      shoulders: "Float shoulder blades down and wide.",
    },
    durationSeconds: 90,
  },
};

const PLACE_DIRECTORY = [
  {
    id: "yoga_haven_toronto",
    name: "Yoga Haven Toronto",
    city: "Toronto",
    province: "ON",
    latitude: 43.65107,
    longitude: -79.347015,
    specialties: ["vinyasa", "prenatal"],
    vibe: "sunlit loft studio with forest-infused playlists",
    introOffer: "First month unlimited for $49",
    website: "https://yogahaventoronto.example.com",
  },
  {
    id: "west_coast_balance",
    name: "West Coast Balance",
    city: "Vancouver",
    province: "BC",
    latitude: 49.282729,
    longitude: -123.120738,
    specialties: ["yin", "soundbath"],
    vibe: "ocean-view lounge with candlelight evening classes",
    introOffer: "Two weeks for $39",
    website: "https://westcoastbalance.example.com",
  },
  {
    id: "prairie_flow",
    name: "Prairie Flow Studio",
    city: "Calgary",
    province: "AB",
    latitude: 51.0447,
    longitude: -114.0719,
    specialties: ["power", "reformer"],
    vibe: "bright, modern space with heated floors",
    introOffer: "Drop-in $22 or 10-pack $180",
    website: "https://prairieflow.example.com",
  },
];

const SUPPORT_TOPICS = {
  membership: {
    summary: "Membership & billing support",
    steps: [
      "Confirm the user's email and membership tier.",
      "Check Stripe subscription status; surface renewal or payment failures.",
      "Offer downgrade/upgrade options and cancellation flow if asked.",
    ],
    escalation: {
      email: "support@smartyoga.ca",
      slaHours: 12,
    },
  },
  technical: {
    summary: "Technical troubleshooting",
    steps: [
      "Capture device type, OS, and app version.",
      "Ask for reproduction steps and whether it happens on Wi-Fi or LTE.",
      "Suggest clearing cache or reinstall if appropriate.",
    ],
    escalation: {
      email: "dev-support@smartyoga.ca",
      slaHours: 24,
    },
  },
  mindfulness: {
    summary: "Mindfulness & wellbeing resources",
    steps: [
      "Share short breath practices from our meditation catalog.",
      "Encourage journaling prompts aligned with the user's goal.",
      "Offer follow-up check-in or schedule a reminder session.",
    ],
    escalation: {
      email: "coaching@smartyoga.ca",
      slaHours: 48,
    },
  },
};

const grokToolDefinitions = [
  {
    type: "function",
    function: {
      name: "guide",
      description: "Fetch a structured coaching script for a pose, including steps, cues, and breath guidance.",
      parameters: {
        type: "object",
        properties: {
          poseId: {
            type: "string",
            description: "Pose identifier such as tree_pose or warrior_ii.",
          },
          focus: {
            type: "string",
            description: "Optional focus area to emphasize (e.g., balance, hips, grounding).",
          },
          level: {
            type: "string",
            description: "Experience level of practitioner (beginner, intermediate, advanced).",
          },
          language: {
            type: "string",
            description: "Target locale code (en-CA, fr-CA, zh-CN).",
          },
        },
        required: ["poseId"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "pose",
      description: "Obtain live scoring or metrics by providing landmarks or imagery to the pose service.",
      parameters: {
        type: "object",
        properties: {
          poseId: { type: "string", description: "Pose identifier or session context." },
          landmarks: {
            type: "array",
            description: "Optional MediaPipe/OpenPose landmark array to score locally.",
            items: {
              type: "object",
              properties: {
                x: { type: "number" },
                y: { type: "number" },
                z: { type: "number" },
                conf: { type: "number" },
                score: { type: "number" },
              },
            },
          },
          image_url: { type: "string", description: "Public image URL when landmarks are not provided." },
          image_base64: { type: "string", description: "Base64 image payload when URL unavailable." },
          includeLandmarks: { type: "boolean", description: "Whether the downstream response should include landmarks." },
          scoring: {
            type: "object",
            description: "Override scoring thresholds (minConf, tolSym, tolVert, extRef).",
            properties: {
              minConf: { type: "number" },
              tolSym: { type: "number" },
              tolVert: { type: "number" },
              extRef: { type: "number" },
            },
          },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "places",
      description: "Recommend Canadian studios or venues near the user for yoga, wellness, or events.",
      parameters: {
        type: "object",
        properties: {
          city: { type: "string" },
          province: { type: "string" },
          coordinates: {
            type: "object",
            properties: {
              latitude: { type: "number" },
              longitude: { type: "number" },
            },
          },
          radiusKm: { type: "number", description: "Search radius in kilometres (default 25)." },
          maxResults: { type: "number", description: "Maximum venues to return (default 3)." },
          purpose: { type: "string", description: "Class, retreat, prenatal, etc." },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "support",
      description: "Surface SmartYoga support playbooks for membership, technical, or wellbeing questions.",
      parameters: {
        type: "object",
        properties: {
          topic: { type: "string", description: "membership, technical, mindfulness, or other." },
          language: { type: "string", description: "Preferred locale code for the response." },
          urgency: { type: "string", description: "Optional: low, normal, high." },
          userEmail: { type: "string", description: "Customer email when escalation is required." },
        },
      },
    },
  },
];

const toNumberOr = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const deg2rad = (deg) => (deg * Math.PI) / 180;

function haversineDistanceKm(a, b) {
  const R = 6371;
  const dLat = deg2rad(b.latitude - a.latitude);
  const dLon = deg2rad(b.longitude - a.longitude);
  const lat1 = deg2rad(a.latitude);
  const lat2 = deg2rad(b.latitude);

  const sinLat = Math.sin(dLat / 2);
  const sinLon = Math.sin(dLon / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLon * sinLon;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return R * c;
}

function resolveGuide({ poseId, language, level, focus }, locale) {
  const guide = POSE_GUIDES[poseId] || POSE_GUIDES.tree_pose;
  const langKey = language || locale || "en-CA";
  const translation = guide.translations[langKey] || guide.translations["en-CA"];
  const focusTip = focus ? guide.focusTips?.[focus] : null;
  return {
    poseId: guide.id,
    language: langKey,
    name: translation.name,
    level: level || "all-levels",
    steps: translation.steps,
    cues: translation.cues,
    breath: translation.breath,
    suggestedDurationSeconds: guide.durationSeconds,
    focus,
    focusTip,
  };
}

async function runPoseTool(args, context) {
  const {
    poseId = "generic",
    landmarks,
    image_url,
    image_base64,
    includeLandmarks,
    scoring = {},
  } = args || {};

  if (Array.isArray(landmarks) && landmarks.length) {
    const overrides = {
      minConf: toNumberOr(scoring.minConf, 0.35),
      tolSym: toNumberOr(scoring.tolSym, 0.18),
      tolVert: toNumberOr(scoring.tolVert, 35),
      extRef: toNumberOr(scoring.extRef, 1.2),
    };
    const result = genericScore(landmarks, overrides);
    return {
      source: "local-generic-score",
      poseId,
      overrides,
      ...result,
    };
  }

  if (!context?.poseUrl) {
    throw new Error("PoseServiceUnavailable");
  }
  if (!image_url && !image_base64) {
    throw new Error("PoseToolMissingInput");
  }

  const payload = {
    poseId,
    image_url,
    image_base64,
    includeLandmarks: Boolean(includeLandmarks),
  };
  const resp = await context.fetch(`${context.poseUrl}/pose/score`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    timeout: 10000,
  });
  const json = await resp.json().catch(() => null);
  if (!resp.ok) {
    const message = json?.error || json?.message || "pose service error";
    throw new Error(message);
  }
  const data = json?.data || json;
  return {
    source: "remote-pose-service",
    poseId,
    ...data,
  };
}

function runPlacesTool(args) {
  const {
    city,
    province,
    coordinates,
    radiusKm = 25,
    maxResults = 3,
    purpose,
  } = args || {};

  let matches = [...PLACE_DIRECTORY];
  if (city) {
    matches = matches.filter((place) => place.city.toLowerCase() === city.toLowerCase());
  }
  if (province) {
    matches = matches.filter((place) => place.province.toLowerCase() === province.toLowerCase());
  }
  if (coordinates && Number.isFinite(coordinates.latitude) && Number.isFinite(coordinates.longitude)) {
    matches = matches
      .map((place) => ({
        ...place,
        distanceKm: haversineDistanceKm(coordinates, place),
      }))
      .filter((place) => place.distanceKm <= radiusKm)
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }
  if (purpose) {
    matches = matches.filter((place) => place.specialties.includes(purpose));
  }

  return {
    total: matches.length,
    results: matches.slice(0, maxResults).map((place) => ({
      id: place.id,
      name: place.name,
      city: place.city,
      province: place.province,
      specialties: place.specialties,
      vibe: place.vibe,
      introOffer: place.introOffer,
      website: place.website,
      distanceKm: place.distanceKm ? Number(place.distanceKm.toFixed(1)) : null,
    })),
  };
}

function runSupportTool(args, locale) {
  const { topic = "membership", language = locale, urgency = "normal", userEmail } = args || {};
  const playbook = SUPPORT_TOPICS[topic] || SUPPORT_TOPICS.membership;
  return {
    topic,
    language,
    summary: playbook.summary,
    steps: playbook.steps,
    escalation: {
      ...playbook.escalation,
      ...(userEmail ? { customerEmail: userEmail } : {}),
      urgency,
    },
  };
}

export async function executeGrokTool(name, args, context = {}) {
  switch (name) {
    case "guide":
      return resolveGuide(args || {}, context.locale);
    case "pose":
      return runPoseTool(args || {}, context);
    case "places":
      return runPlacesTool(args || {});
    case "support":
      return runSupportTool(args || {}, context.locale);
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

export { grokToolDefinitions };
