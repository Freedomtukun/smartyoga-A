// ESM 模式下运行（确保 package.json 有 "type": "module"）
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import fetch from "node-fetch"; // v3+
import pino from "pino";
import pinoHttp from "pino-http";
import { EventEmitter } from "events";

import { genericScore } from "./lib/poseMetrics.js";
import { GrokClient } from "./grok/client.js";
import { buildSystemPrompt, resolvePersona } from "./grok/prompt.js";
import { executeGrokTool, grokToolDefinitions } from "./grok/tools.js";
import firestore from "./lib/firestore.js";
import createAudioClient from "./lib/audioClient.js";
import { callOpenAIRealtime, isOpenAIRealtimeEnabled } from "./lib/openaiRealtime.js";
import { evaluateGuardrails } from "./lib/guardrails.js";
import {
  getUserMemory,
  upsertUserMemory,
  listMemoryEntries,
  addMemoryEntry,
  recordPoseSample,
  resolveAdaptiveThresholds,
} from "./memory/store.js";
import setupRealtimeServer from "./realtime/server.js";

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
const eventBus = new EventEmitter();
eventBus.setMaxListeners(0);
const RECENT_EVENT_LIMIT = 50;
const recentPoseEvents = [];


// ---- 中间件 ----
app.use(cors({ origin: "*", methods: ["GET", "POST", "OPTIONS"], allowedHeaders: ["Content-Type", "x-api-key"] }));
app.use(bodyParser.json({ limit: "6mb" })); // 允许传入 base64
app.use(pinoHttp({ logger: log }));

// ---- 外部服务与客户端 ----
const POSE_URL = process.env.POSE_SERVICE_URL || process.env.POSE_URL || null; // 兼容历史配置
if (!POSE_URL) {
  log.warn("POSE_URL is not set. /pose/score will fail when trying to call pose service.");
}

const audioClient = createAudioClient({ log });
if (!audioClient.hasTts) {
  log.warn("Audio TTS service not configured; audio responses disabled.");
}
if (!audioClient.hasStt) {
  log.warn("Audio STT service not configured; realtime transcription will be stubbed.");
}

const grokClient = new GrokClient({
  apiKey: process.env.GROK_API_KEY,
  baseUrl: process.env.GROK_BASE_URL || "https://api.x.ai",
  model: process.env.GROK_MODEL || "grok-4-fast-reasoning",
  fetchImpl: fetch,
  log,
});

const toNumberOr = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const toBoolean = (value, fallback = false) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["1", "true", "yes", "y", "on"].includes(normalized)) return true;
    if (["0", "false", "no", "n", "off"].includes(normalized)) return false;
    return fallback;
  }
  if (typeof value === "number") return value > 0;
  return fallback;
};

const clampNumber = (value, minValue, maxValue) => Math.max(minValue, Math.min(maxValue, value));
const MAX_TOOL_ITERATIONS = 3;
const MAX_MESSAGE_LENGTH = 4000;

const sanitizeMessages = (messages = []) =>
  messages
    .map((msg) => {
      if (!msg) return null;
      const role = msg.role === "assistant" ? "assistant" : "user";
      const content = typeof msg.content === "string" ? msg.content.trim() : "";
      if (!content) return null;
      return { role, content: content.slice(0, MAX_MESSAGE_LENGTH) };
    })
    .filter(Boolean);

const parseToolArguments = (toolCall, logger) => {
  const raw = toolCall?.function?.arguments;
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch (err) {
    logger?.warn({ err, tool: toolCall?.function?.name }, "invalid tool arguments payload");
    return {};
  }
};

const toIsoString = (value) => {
  if (!value) return null;
  if (typeof value.toDate === "function") {
    try {
      return value.toDate().toISOString();
    } catch (err) {
      return null;
    }
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (typeof value === "string") {
    return value;
  }
  return null;
};

const serializeMemoryDoc = (doc) => {
  if (!doc) return null;
  return {
    userId: doc.userId,
    profile: doc.profile || null,
    preferences: doc.preferences || null,
    stats: doc.stats || null,
    summary: doc.summary
      ? {
          text: doc.summary.text ?? null,
          updatedAt: toIsoString(doc.summary.updatedAt),
          tokens: doc.summary.tokens ?? 0,
        }
      : null,
    lastEntryPreview: doc.lastEntryPreview
      ? {
          type: doc.lastEntryPreview.type ?? null,
          content: doc.lastEntryPreview.content ?? null,
          createdAt: toIsoString(doc.lastEntryPreview.createdAt),
        }
      : null,
    createdAt: toIsoString(doc.createdAt),
    updatedAt: toIsoString(doc.updatedAt),
  };
};

const serializeMemoryEntry = (entry) => ({
  entryId: entry.entryId,
  type: entry.type ?? null,
  source: entry.source ?? null,
  content: entry.content ?? null,
  summary: entry.summary ?? null,
  tags: entry.tags ?? [],
  score: entry.score ?? null,
  metadata: entry.metadata ?? {},
  createdAt: toIsoString(entry.createdAt),
});

const truncate = (text, max = 240) => {
  if (typeof text !== "string") return "";
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
};

const latestUserUtterance = (messages = []) => {
  for (let idx = messages.length - 1; idx >= 0; idx -= 1) {
    const item = messages[idx];
    if (item?.role === "user" && item.content) {
      return item.content;
    }
  }
  return null;
};


// ---- 路由 ----
// Pose events ingestion (from pose service)
app.post("/events/pose", (req, res) => {
  const payload = req.body || {};
  if (!payload || typeof payload !== 'object') {
    return res.status(400).json({ ok: false, error: 'invalid_payload' });
  }
  const event = {
    ts: Date.now(),
    source: 'pose-service',
    frame: payload.frame ?? null,
    poses: payload.poses ?? payload.data ?? [],
    meta: payload.meta ?? {},
  };
  recentPoseEvents.push(event);
  if (recentPoseEvents.length > RECENT_EVENT_LIMIT) {
    recentPoseEvents.splice(0, recentPoseEvents.length - RECENT_EVENT_LIMIT);
  }
  eventBus.emit('pose', event);
  res.json({ ok: true });
});

// Server-Sent Events stream for pose updates
app.get("/events/pose/stream", (req, res) => {
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  if (typeof res.flushHeaders === 'function') res.flushHeaders();
  const send = (event) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };
  recentPoseEvents.forEach(send);
  eventBus.on('pose', send);
  req.on('close', () => {
    eventBus.off('pose', send);
  });
});

app.get("/health", (req, res) => {
  res.json({ ok: true, ts: Date.now(), pose: POSE_URL || null });
});

// 最近 N 条日志（默认 5）
app.get("/pose/logs", async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit || "5", 10), 50);
    const snapshot = await firestore.collection("pose_logs")
      .orderBy("timestamp", "desc").limit(limit).get();
    const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json({ ok: true, data });
  } catch (e) {
    req.log.error({ err: e }, "logs error");
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get("/memory/:userId", async (req, res) => {
  const { userId } = req.params;
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId required" });
  }
  try {
    const memory = await getUserMemory(userId);
    res.json({ ok: true, data: serializeMemoryDoc(memory) });
  } catch (err) {
    req.log.error({ err, userId }, "memory fetch failed");
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.patch("/memory/:userId", async (req, res) => {
  const { userId } = req.params;
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId required" });
  }
  try {
    const memory = await upsertUserMemory(userId, req.body || {});
    res.json({ ok: true, data: serializeMemoryDoc(memory) });
  } catch (err) {
    req.log.error({ err, userId }, "memory update failed");
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/memory/:userId/entries", async (req, res) => {
  const { userId } = req.params;
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId required" });
  }
  const limit = Math.min(parseInt(req.query.limit || "20", 10), 100);
  const order = req.query.order === "asc" ? "asc" : "desc";
  try {
    const entries = await listMemoryEntries(userId, { limit, order });
    res.json({ ok: true, data: entries.map(serializeMemoryEntry) });
  } catch (err) {
    req.log.error({ err, userId }, "memory entries fetch failed");
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/memory/:userId/entries", async (req, res) => {
  const { userId } = req.params;
  if (!userId) {
    return res.status(400).json({ ok: false, error: "userId required" });
  }
  if (!req.body || !req.body.content) {
    return res.status(400).json({ ok: false, error: "content is required" });
  }
  try {
    const entry = await addMemoryEntry(userId, req.body);
    res.status(201).json({ ok: true, data: serializeMemoryEntry(entry) });
  } catch (err) {
    req.log.error({ err, userId }, "memory entry create failed");
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/ai/chat", async (req, res) => {
  const {
    messages,
    persona: personaId,
    locale,
    context = {},
    temperature,
    maxOutputTokens,
    includeAudio: includeAudioRequest,
    voiceId: overrideVoiceId,
    provider: providerPreference,
  } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ ok: false, error: "messages array required" });
  }

  const sanitized = sanitizeMessages(messages);
  if (sanitized.length === 0) {
    return res.status(400).json({ ok: false, error: "no valid messages" });
  }

  const safeContext = context && typeof context === "object" ? context : {};

  let userMemory = null;
  if (safeContext.userId) {
    try {
      userMemory = await getUserMemory(safeContext.userId);
    } catch (err) {
      req.log.warn({ err, userId: safeContext.userId }, "memory preload failed");
    }
  }

  const personaPreference = personaId || userMemory?.profile?.preferredPersona;
  const persona = resolvePersona(personaPreference);
  const activeLocale = locale || userMemory?.profile?.locale || persona.defaultLocale;
  const memorySummary = safeContext?.memorySummary ?? userMemory?.summary?.text ?? null;
  const sessionGoal = safeContext?.goal
    ?? (Array.isArray(userMemory?.profile?.goals) && userMemory.profile.goals.length
      ? userMemory.profile.goals[0]
      : null);
  const includeAudio = toBoolean(includeAudioRequest ?? safeContext?.includeAudio, false);
  const preferredVoice =
    overrideVoiceId
    || safeContext?.voiceId
    || userMemory?.profile?.ttsVoice
    || persona.voiceId
    || process.env.DEFAULT_TTS_VOICE
    || "alloy";

  const systemPrompt = buildSystemPrompt({
    persona,
    locale: activeLocale,
    memorySummary,
    sessionGoal,
  });

  const providerRaw = typeof providerPreference === "string" ? providerPreference.toLowerCase() : null;
  let provider = providerRaw || (process.env.AI_BACKEND || "auto").toLowerCase();
  if (provider === "auto") {
    provider = isOpenAIRealtimeEnabled ? "openai" : "grok";
  }
  if (provider === "openai" && !isOpenAIRealtimeEnabled) {
    provider = grokClient.isEnabled ? "grok" : "openai";
  }
  if (provider === "grok" && !grokClient.isEnabled) {
    provider = isOpenAIRealtimeEnabled ? "openai" : "grok";
  }
  if (provider !== "openai" && provider !== "grok") {
    provider = isOpenAIRealtimeEnabled ? "openai" : (grokClient.isEnabled ? "grok" : "openai");
  }
  if (provider === "grok" && !grokClient.isEnabled) {
    return res.status(503).json({ ok: false, error: "AI backend unavailable" });
  }
  if (provider === "openai" && !isOpenAIRealtimeEnabled && !grokClient.isEnabled) {
    return res.status(503).json({ ok: false, error: "AI backend unavailable" });
  }

  const conversation = [{ role: "system", content: systemPrompt }, ...sanitized];
  const temperatureValue = clampNumber(toNumberOr(temperature, 0.6), 0, 1.2);
  const maxTokens = Number.isFinite(maxOutputTokens) ? maxOutputTokens : undefined;

  let reply = "";
  let finishReason = null;
  let usage = null;
  let audioPayload = null;
  const toolInvocations = [];
  let finalAssistantMessage = null;
  let finalResponse = null;
  let memoryEntry = null;

  if (provider === "openai") {
    try {
      const result = await callOpenAIRealtime({
        systemPrompt,
        messages: sanitized,
        includeAudio,
        voiceId: preferredVoice,
        temperature: temperatureValue,
        maxOutputTokens: maxTokens,
      });
      reply = result.reply || "";
      usage = result.raw?.usage ?? null;
      finishReason = result.raw?.output?.[0]?.finish_reason ?? null;
      if (result.audio) {
        audioPayload = {
          url: result.audio.url,
          engine: "openai-realtime",
          voiceId: preferredVoice,
          format: result.audio.format,
          durationMs: null,
        };
      }
    } catch (err) {
      req.log.error({ err }, "openai realtime call failed");
      if (!grokClient.isEnabled) {
        return res.status(502).json({ ok: false, error: "openai_realtime_failed" });
      }
      provider = "grok";
    }
  }

  if (provider === "grok" && !reply) {
    try {
      for (let iteration = 0; iteration < MAX_TOOL_ITERATIONS; iteration += 1) {
        const response = await grokClient.chat({
          messages: conversation,
          tools: grokToolDefinitions,
          temperature: temperatureValue,
          maxOutputTokens: maxTokens,
        });
        finalResponse = response;
        const choice = response?.choices?.[0];
        const assistantMessage = choice?.message;
        if (!assistantMessage) break;
        finalAssistantMessage = assistantMessage;

        if (Array.isArray(assistantMessage.tool_calls) && assistantMessage.tool_calls.length) {
          conversation.push({
            role: assistantMessage.role || "assistant",
            content: assistantMessage.content || "",
            tool_calls: assistantMessage.tool_calls,
          });

          for (const toolCall of assistantMessage.tool_calls) {
            const args = parseToolArguments(toolCall, req.log);
            try {
              const result = await executeGrokTool(toolCall.function?.name, args, {
                ...safeContext,
                locale: activeLocale,
                persona,
                fetch,
                poseUrl: POSE_URL,
                memory: userMemory,
              });
              const payload = { status: "ok", data: result };
              conversation.push({
                role: "tool",
                tool_call_id: toolCall.id,
                name: toolCall.function?.name,
                content: JSON.stringify(payload),
              });
              toolInvocations.push({
                id: toolCall.id,
                name: toolCall.function?.name,
                arguments: args,
                status: "ok",
                result,
              });
            } catch (toolErr) {
              req.log.warn({ err: toolErr, tool: toolCall.function?.name }, "grok tool execution failed");
              const payload = { status: "error", error: toolErr.message };
              conversation.push({
                role: "tool",
                tool_call_id: toolCall.id,
                name: toolCall.function?.name,
                content: JSON.stringify(payload),
              });
              toolInvocations.push({
                id: toolCall.id,
                name: toolCall.function?.name,
                arguments: args,
                status: "error",
                error: toolErr.message,
              });
            }
          }
          continue;
        }

        conversation.push({
          role: assistantMessage.role || "assistant",
          content: assistantMessage.content || "",
        });
        break;
      }

      reply = finalAssistantMessage?.content || "";
      finishReason = finalResponse?.choices?.[0]?.finish_reason || null;
      usage = finalResponse?.usage || null;
    } catch (err) {
      req.log.error({ err }, "grok chat error");
      return res.status(500).json({ ok: false, error: err.message });
    }
  }

  if (!reply) {
    return res.status(502).json({ ok: false, error: "empty_reply" });
  }

  const guardrailsResult = await evaluateGuardrails({ text: reply, persona, userId: safeContext.userId });
  if (!guardrailsResult.allowed) {
    toolInvocations.push({ name: 'guardrails', status: 'blocked', reasons: guardrailsResult.reasons });
    reply = guardrailsResult.text;
    audioPayload = null;
  }

  const latestUser = latestUserUtterance(sanitized);
  if (safeContext.userId && userMemory && safeContext.persistMemory !== false) {
    try {
      const entry = await addMemoryEntry(safeContext.userId, {
        type: "conversation",
        source: provider === "openai" ? "ai.chat.openai" : "ai.chat.grok",
        content: truncate(reply, 600),
        summary: latestUser
          ? `User: ${truncate(latestUser, 200)} | Coach: ${truncate(reply, 200)}`
          : truncate(reply, 240),
        tags: [persona.id, activeLocale].filter(Boolean),
        metadata: {
          latestUser: latestUser ? truncate(latestUser, 400) : null,
          finishReason,
          toolCalls: toolInvocations.length,
          promptTokens: usage?.prompt_tokens ?? null,
          completionTokens: usage?.completion_tokens ?? null,
          audioRequested: Boolean(includeAudio),
          voiceId: preferredVoice,
          provider,
          safetyStatus: guardrailsResult.allowed ? 'allowed' : 'blocked',
          safetyReasons: guardrailsResult.reasons || [],
        },
      });
      memoryEntry = serializeMemoryEntry(entry);
      try {
        userMemory = await getUserMemory(safeContext.userId);
      } catch (refreshErr) {
        req.log.warn({ err: refreshErr, userId: safeContext.userId }, "memory refresh failed");
      }
    } catch (memErr) {
      req.log.warn({ err: memErr, userId: safeContext.userId }, "memory append failed");
    }
  }

  if (includeAudio && reply && audioClient.hasTts && !audioPayload) {
    try {
      const tts = await audioClient.synthesize({ text: reply, voiceId: preferredVoice, format: "mp3" });
      audioPayload = {
        url: tts.audioUrl,
        durationMs: tts.durationMs,
        engine: tts.engine,
        generatedAt: tts.generatedAt,
        voiceId: preferredVoice,
      };
    } catch (ttsErr) {
      req.log.warn({ err: ttsErr }, "tts synthesis failed");
    }
  }

  res.json({
    ok: true,
    data: {
      persona: persona.id,
      locale: activeLocale,
      reply,
      finishReason,
      toolInvocations,
      usage,
      memory: serializeMemoryDoc(userMemory),
      memoryEntry,
      audio: audioPayload,
      provider,
      guardrails: guardrailsResult,
    },
  });
});

app.post("/commerce/checkout", async (req, res) => {
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) {
    return res.status(503).json({ ok: false, error: "stripe_not_configured" });
  }
  const priceId = req.body?.priceId || process.env.STRIPE_PRICE_ID_PREMIUM;
  if (!priceId) {
    return res.status(400).json({ ok: false, error: "price_id_required" });
  }
  const successUrl = req.body?.successUrl || process.env.FRONTEND_BASE_URL || "https://smartyoga.ca/success";
  const cancelUrl = req.body?.cancelUrl || process.env.FRONTEND_BASE_URL || "https://smartyoga.ca/cancel";
  const customerEmail = req.body?.email || null;
  const params = new URLSearchParams();
  params.append("mode", "subscription");
  params.append("line_items[0][price]", priceId);
  params.append("line_items[0][quantity]", String(req.body?.quantity || 1));
  params.append("success_url", successUrl);
  params.append("cancel_url", cancelUrl);
  if (customerEmail) {
    params.append("customer_email", customerEmail);
  }
  if (req.body?.metadata && typeof req.body.metadata === "object") {
    for (const [key, value] of Object.entries(req.body.metadata)) {
      params.append(`metadata[${key}]`, String(value));
    }
  }
  try {
    const stripeRes = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${stripeKey}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params,
    });
    if (!stripeRes.ok) {
      const detail = await stripeRes.text();
      return res.status(502).json({ ok: false, error: "stripe_error", detail });
    }
    const session = await stripeRes.json();
    res.json({ ok: true, data: { id: session.id, url: session.url } });
  } catch (err) {
    req.log.error({ err }, "stripe checkout create failed");
    res.status(500).json({ ok: false, error: err.message });
  }
});

// 核心：调用云端检测 + 后端打分 + 写库
app.post("/pose/score", async (req, res) => {
  const started = Date.now();
  try {
    const {
      userId = "anonymous",
      poseId = "generic",
      image_base64,
      image_url,
      landmarks,
      includeLandmarks: bodyInclude,
    } = req.body || {};
    const includeToken = req.query.includeLandmarks ?? bodyInclude;
    const includeLandmarks = toBoolean(includeToken, false);
    const meta = { ...(req.body?.meta || {}) };
    let userMemoryDoc = null;
    if (userId && userId !== "anonymous") {
      try {
        userMemoryDoc = await getUserMemory(userId);
      } catch (err) {
        req.log?.warn?.({ err, userId }, "pose memory fetch failed");
      }
    }
    const adaptiveThresholds = resolveAdaptiveThresholds(userMemoryDoc);

    // 1) 先拿 landmarks：优先用客户端上传；否则调用 pose 服务
    let lm = Array.isArray(landmarks) ? landmarks : null;
    if (!lm || lm.length === 0) {
      if (!POSE_URL) return res.status(500).json({ ok: false, error: "POSE_URL not configured" });
      if (!image_base64 && !image_url) {
        return res.status(400).json({ ok: false, error: "image_base64 or image_url required" });
      }

      const poseReq = { image_base64, image_url };
      const r = await fetch(`${POSE_URL}/pose/detect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(poseReq),
        // Cloud Run pose 默认很快；给 8s 上限避免长时间挂起
        timeout: 8000
      });
      const pose = await r.json().catch(() => ({}));
      if (!pose || !pose.ok) {
        return res.status(502).json({ ok: false, error: "pose service failed" });
      }
      const poseData = pose.data || {};
      if (Array.isArray(poseData.poses) && poseData.poses.length) {
        lm = poseData.poses[0]?.landmarks || [];
        meta.width = poseData.meta?.width ?? meta.width;
        meta.height = poseData.meta?.height ?? meta.height;
      } else {
        lm = poseData.landmarks || [];
      }
    }

    if (!Array.isArray(lm) || lm.length === 0) {
      // 未检测到人体也写入一次，便于后期分析召回
      await firestore.collection("pose_logs").add({
        userId,
        poseId,
        timestamp: Date.now(),
        landmarks: [],
        score: 0,
        stability: null,
        reason: "no_person",
        meta,
      });
      return res.json({
        ok: true,
        data: {
          score: 0,
          advice: "No body detected. Adjust framing or lighting and try again.",
          summary: "Reposition and retry.",
          meta,
        },
      });
    }

    // 2) 计算分数（通用指标，可在后续替换为 poseId 专用函数）
    if (adaptiveThresholds) {
      meta.adaptiveThresholds = adaptiveThresholds;
    }
    const baseThresholds = {
      minConf: adaptiveThresholds?.minConf ?? 0.35,
      tolSym: adaptiveThresholds?.tolSym ?? 0.18,
      tolVert: adaptiveThresholds?.tolVert ?? 35,
      extRef: adaptiveThresholds?.extRef ?? 1.2,
    };
    const scoringOverrides = {
      minConf: toNumberOr(req.query?.minConf ?? req.body?.scoring?.minConf, baseThresholds.minConf),
      tolSym: toNumberOr(req.query?.tolSym ?? req.body?.scoring?.tolSym, baseThresholds.tolSym),
      tolVert: toNumberOr(req.query?.tolVert ?? req.body?.scoring?.tolVert, baseThresholds.tolVert),
      extRef: toNumberOr(req.query?.extRef ?? req.body?.scoring?.extRef, baseThresholds.extRef),
    };
    const { score, metrics, advice, summary } = genericScore(lm, scoringOverrides);
    const stability = null; // 可在此加入抖动估计等

    // 3) Firestore 入库（对象数组 OK；不要二维数组）
    await firestore.collection("pose_logs").add({
      userId,
      poseId,
      timestamp: Date.now(),
      landmarks: lm,
      score,
      stability,
      metrics,
      rt_ms: Date.now() - started,
      frameWidth: meta.width ?? null,
      frameHeight: meta.height ?? null,
    });

    if (userMemoryDoc) {
      try {
        await recordPoseSample(userId, { poseId, score, metrics });
      } catch (err) {
        req.log?.warn?.({ err, userId }, "record pose sample failed");
      }
    }

    // 4) 返回给前端
    res.json({
      ok: true,
      data: {
        score,
        advice,
        summary,
        metrics,
        meta,
        ...(includeLandmarks ? { landmarks: lm } : {}),
      },
    });
  } catch (err) {
    req.log.error({ err }, "pose/score error");
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ---- 兜底 404 ----
app.use((req, res) => res.status(404).json({ ok: false, error: "Not Found" }));

// ---- 启动 ----
const PORT = Number(
  process.env.API_PORT ||
  process.env.PORT ||
  process.env.FASTAPI_PORT ||
  8080
);
const server = app.listen(PORT, () => log.info({ PORT, POSE_URL }, "✅ API listening"));

setupRealtimeServer({
  server,
  log,
  port: PORT,
  sttUrl: audioClient.sttUrl || null,
  ttsUrl: audioClient.ttsUrl || null,
  defaultVoice: process.env.DEFAULT_TTS_VOICE || "alloy",
}).catch((err) => {
  log.error({ err }, "realtime server failed to start");
});
