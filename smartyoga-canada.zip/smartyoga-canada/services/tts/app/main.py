from __future__ import annotations

import asyncio
import base64
import io
import json
import logging
import os
import uuid
import wave
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field


LOG = logging.getLogger("smartyoga.tts")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))


class TTSRequest(BaseModel):
    text: str = Field(min_length=1)
    voice_id: str = Field(default="alloy")
    format: str = Field(default="mp3")
    session_id: Optional[str] = None
    fallback: Optional[str] = Field(default="piper")


class TTSResponse(BaseModel):
    audio_url: str
    duration_ms: int
    engine: str
    generated_at: datetime


class STTRequest(BaseModel):
    audio_base64: str
    sample_rate: int = Field(default=16000, gt=0)
    encoding: str = Field(default="pcm16")
    language: Optional[str] = None


class STTResponse(BaseModel):
    text: str
    engine: str
    duration_ms: Optional[int] = None
    confidence: Optional[float] = None


class AudioMiniResult(BaseModel):
    path: str
    duration_ms: int
    engine: str = "audio-mini"
    mime_type: str = Field(default="audio/mpeg")


class AudioMiniClient:
    def __init__(self) -> None:
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self.tts_model = os.getenv("AUDIO_MINI_TTS_MODEL", "gpt-4o-mini-tts")
        self.stt_model = os.getenv("AUDIO_MINI_STT_MODEL", "gpt-4o-mini-transcribe")
        self.timeout = float(os.getenv("AUDIO_MINI_TIMEOUT", "15"))
        self._client: Optional[httpx.AsyncClient] = None
        self._lock = asyncio.Lock()

    @property
    def is_enabled(self) -> bool:
        return bool(self.api_key)

    async def _http(self) -> httpx.AsyncClient:
        async with self._lock:
            if self._client is None:
                self._client = httpx.AsyncClient(
                    base_url=self.base_url,
                    timeout=self.timeout,
                    headers={"Authorization": f"Bearer {self.api_key}"} if self.api_key else {},
                )
            return self._client

    async def close(self) -> None:
        async with self._lock:
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    async def synthesize(self, text: str, voice_id: str, fmt: str) -> AudioMiniResult:
        if not self.is_enabled:
            raise RuntimeError("audio_mini_disabled")

        client = await self._http()
        payload = {
            "model": self.tts_model,
            "voice": voice_id,
            "input": text,
            "format": fmt,
        }
        LOG.debug("AudioMini synth payload: %s", json.dumps({k: v for k, v in payload.items() if k != "input"}))
        resp = await client.post("/audio/speech", json=payload)
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            LOG.warning("AudioMini TTS error: %s", exc.response.text)
            raise

        audio_bytes = resp.content
        duration_ms = _extract_duration_ms(resp.headers) or max(1200, len(text) * 55)
        mime_type = resp.headers.get("content-type", "audio/mpeg")
        path = _write_tmp_audio(audio_bytes, suffix=f".{fmt if fmt in ('mp3','wav','aac','ogg') else 'mp3'}")
        return AudioMiniResult(path=path, duration_ms=duration_ms, mime_type=mime_type)

    async def transcribe(self, audio_bytes: bytes, sample_rate: int, encoding: str, language: Optional[str]) -> dict:
        if not self.is_enabled:
            raise RuntimeError("audio_mini_disabled")

        client = await self._http()
        wav_bytes, filename = _ensure_wav(audio_bytes, sample_rate, encoding)
        files = {"file": (filename, wav_bytes, "audio/wav")}
        data = {"model": self.stt_model}
        if language:
            data["language"] = language
        resp = await client.post("/audio/transcriptions", data=data, files=files)
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            LOG.warning("AudioMini STT error: %s", exc.response.text)
            raise
        return resp.json()


class PiperEngine:
    def __init__(self, model_path: str | None = None) -> None:
        self.model_path = model_path

    async def synthesize(self, text: str, voice_id: str, fmt: str) -> Tuple[str, int]:
        await asyncio.sleep(min(1.0, len(text) / 120.0))
        slug = text.lower().replace(" ", "-")[:30] or "tts"
        filename = f"tts-{voice_id}-{slug}.{fmt}"
        output_dir = Path("/tmp/tts")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / filename
        output_path.write_bytes(b"FAKEAUDIO")
        return str(output_path), max(1200, len(text) * 60)


class CoquiFallback:
    async def synthesize(self, text: str) -> tuple[str, int]:
        await asyncio.sleep(0.5)
        return "https://tts-backup.smartyoga.ca/audio/demo.mp3", len(text) * 50


class PseudoSTTFallback:
    async def transcribe(self, audio_bytes: bytes) -> str:
        await asyncio.sleep(0.1)
        return f"[audio {len(audio_bytes)} bytes]"


audio_mini = AudioMiniClient()
piper = PiperEngine(model_path=os.getenv("PIPER_MODEL_PATH"))
coqui = CoquiFallback()
stt_fallback = PseudoSTTFallback()

app = FastAPI(title="SmartYoga Audio Service")


@app.on_event("shutdown")
async def on_shutdown() -> None:
    await audio_mini.close()


@app.get("/healthz")
async def healthz() -> dict:
    return {
        "status": "ok",
        "service": "audio",
        "audio_mini": audio_mini.is_enabled,
        "tts_model": audio_mini.tts_model if audio_mini.is_enabled else None,
    }


@app.post("/v1/tts/speak", response_model=TTSResponse)
async def speak(request: TTSRequest) -> TTSResponse:
    errors = []
    if audio_mini.is_enabled:
        try:
            result = await audio_mini.synthesize(request.text, request.voice_id, request.format)
            audio_url = _local_url(result.path)
            return TTSResponse(
                audio_url=audio_url,
                duration_ms=result.duration_ms,
                engine="audio-mini",
                generated_at=datetime.utcnow(),
            )
        except Exception as exc:  # pragma: no cover - upstream dependency
            LOG.warning("AudioMini synth failed, fallback to local engines: %s", exc)
            errors.append(str(exc))

    if request.fallback == "coqui":
        audio_url, duration = await coqui.synthesize(request.text)
        return TTSResponse(audio_url=audio_url, duration_ms=duration, engine="coqui", generated_at=datetime.utcnow())

    path, duration = await piper.synthesize(request.text, request.voice_id, request.format)
    return TTSResponse(
        audio_url=_local_url(path),
        duration_ms=duration,
        engine="piper",
        generated_at=datetime.utcnow(),
    )


@app.post("/v1/stt/transcribe", response_model=STTResponse)
async def transcribe(request: STTRequest) -> STTResponse:
    try:
        audio_bytes = base64.b64decode(request.audio_base64)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="invalid_audio_base64") from exc

    if audio_mini.is_enabled:
        try:
            result = await audio_mini.transcribe(audio_bytes, request.sample_rate, request.encoding, request.language)
            return STTResponse(
                text=result.get("text") or result.get("transcript") or "",
                engine="audio-mini",
                duration_ms=int(float(result.get("duration", 0)) * 1000) if result.get("duration") else None,
                confidence=result.get("confidence"),
            )
        except Exception as exc:  # pragma: no cover
            LOG.warning("AudioMini transcription failed: %s", exc)

    transcript = await stt_fallback.transcribe(audio_bytes)
    return STTResponse(text=transcript, engine="stub")


def _extract_duration_ms(headers: httpx.Headers) -> Optional[int]:
    try:
        duration = headers.get("x-openai-audio-duration")
        if duration is None:
            return None
        return int(float(duration) * 1000)
    except Exception:
        return None


def _write_tmp_audio(audio_bytes: bytes, suffix: str = ".mp3") -> str:
    output_dir = Path("/tmp/tts")
    output_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid.uuid4().hex}{suffix}"
    path = output_dir / filename
    path.write_bytes(audio_bytes)
    return str(path)


def _local_url(path: str) -> str:
    return f"file://{path}"


def _ensure_wav(audio_bytes: bytes, sample_rate: int, encoding: str) -> Tuple[bytes, str]:
    if encoding.lower() != "pcm16":
        return audio_bytes, "audio-input"
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_bytes)
    return buffer.getvalue(), "audio.wav"
