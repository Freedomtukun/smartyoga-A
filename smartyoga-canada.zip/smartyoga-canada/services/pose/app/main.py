import asyncio
import base64
import io
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from PIL import Image

import mediapipe as mp
import json

try:
    import httpx
except ImportError:  # pragma: no cover - httpx is optional during bootstrap
    httpx = None


app = FastAPI(title="SmartYoga Pose Service", version="2.5.0")

PoseLandmarker = None
PoseLandmarkerOptions = None
VisionRunningMode = None
mp_image_module = None

try:
    from mediapipe.tasks import BaseOptions as MpBaseOptions
    from mediapipe.tasks import python as mp_python_tasks
    from mediapipe.tasks.python import vision as mp_vision

    PoseLandmarker = mp_vision.PoseLandmarker
    PoseLandmarkerOptions = mp_vision.PoseLandmarkerOptions
    VisionRunningMode = mp_vision.RunningMode
except Exception:  # pragma: no cover - mediapipe tasks may be unavailable locally
    PoseLandmarker = None

mp_pose = mp.solutions.pose


class DetectRequest(BaseModel):
    image_base64: Optional[str] = None
    image_url: Optional[str] = None
    participant_id: Optional[str] = None
    timestamp_ms: Optional[int] = None


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {"ok": True, "service": "pose", "mode": PoseEngine.instance().mode}


@app.post("/pose/detect")
async def detect(req: DetectRequest) -> JSONResponse:
    """
    静态姿态检测接口，向后兼容 v2 玩法。
    """
    try:
        np_img = await load_image(req)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    engine = PoseEngine.instance()
    result = await engine.detect(np_img, timestamp_ms=req.timestamp_ms)
    payload = {
        "ok": True,
        "data": {
            "poses": result.poses,
            "meta": {
                "width": result.width,
                "height": result.height,
                "mode": engine.mode,
            },
        },
    }
    return JSONResponse(payload)


@app.websocket("/pose/stream")
async def pose_stream(ws: WebSocket) -> None:
    """
    WebSocket 实时姿态流接口：
    - Client 发送 {type: "frame", frame: "...", image_base64: "...", ts: 123}
    - Server 返回 {type: "pose", frame: "...", poses: [...]}
    """
    await ws.accept()
    session = PoseStreamSession(ws, PoseEngine.instance())
    try:
        await session.run()
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # pragma: no cover - defensive safety
        await session.close(code=1011, reason=str(exc))


async def load_image(req: DetectRequest) -> np.ndarray:
    if req.image_base64:
        b64 = req.image_base64.split(",")[-1]
        try:
            data = base64.b64decode(b64, validate=True)
        except Exception as exc:
            raise ValueError("invalid_base64_image") from exc
        return to_rgb_array(data)

    if req.image_url:
        if httpx is None:
            raise ValueError("image_url requires httpx dependency")
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(req.image_url)
            resp.raise_for_status()
            return to_rgb_array(resp.content)

    raise ValueError("image_base64 required")


def to_rgb_array(raw_bytes: bytes) -> np.ndarray:
    image = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
    array = np.array(image)
    max_dim = int(os.environ.get("POSE_MAX_DIM", "960"))
    h, w = array.shape[:2]
    if max(h, w) <= max_dim:
        return array
    scale = max_dim / max(h, w)
    new_size = (int(w * scale), int(h * scale))
    resized = Image.fromarray(array).resize(new_size)
    return np.array(resized)


@dataclass
class PoseResult:
    poses: List[Dict[str, Any]]
    width: int
    height: int


class PoseEngine:
    _instance = None
    _instance_lock = asyncio.Lock()

    def __init__(self) -> None:
        self.mode = "legacy"
        self._pose_landmarker = None
        self._landmarker_lock = asyncio.Lock()
        self._legacy_pose = None
        self._legacy_lock = asyncio.Lock()
        self._load_models()

    @classmethod
    def instance(cls) -> "PoseEngine":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _load_models(self) -> None:
        model_path = Path(os.environ.get("POSE_MODEL_PATH", "/models/pose_landmarker_full.task"))
        max_poses = int(os.environ.get("POSE_MAX_PERSONS", "4"))
        if PoseLandmarker and model_path.exists():
            base_options = MpBaseOptions(model_asset_path=str(model_path))
            options = PoseLandmarkerOptions(
                base_options=base_options,
                running_mode=VisionRunningMode.VIDEO,
                num_poses=max(1, max_poses),
                min_pose_detection_confidence=0.35,
                min_pose_presence_confidence=0.35,
                min_tracking_confidence=0.35,
                output_segmentation_masks=False,
            )
            self._pose_landmarker = PoseLandmarker.create_from_options(options)
            self.mode = "tasks"
        else:
            self._legacy_pose = mp_pose.Pose(
                static_image_mode=False,
                model_complexity=1,
                enable_segmentation=False,
                smooth_landmarks=True,
            )
            self.mode = "legacy"

    async def detect(self, frame: np.ndarray, timestamp_ms: Optional[int] = None) -> PoseResult:
        if self.mode == "tasks" and self._pose_landmarker is not None:
            return await self._detect_with_landmarker(frame, timestamp_ms)
        return await self._detect_with_legacy(frame)

    async def _detect_with_landmarker(self, frame: np.ndarray, timestamp_ms: Optional[int]) -> PoseResult:
        async with self._landmarker_lock:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(
                None, self._landmarker_detect_sync, frame, timestamp_ms or int(time.time() * 1000)
            )

    def _landmarker_detect_sync(self, frame: np.ndarray, timestamp_ms: int) -> PoseResult:
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame)
        result = self._pose_landmarker.detect_for_video(mp_image, timestamp_ms)
        poses = []
        for idx, landmarks in enumerate(result.pose_landmarks or []):
            coords = []
            xs, ys = [], []
            confidence_values = []
            for lm in landmarks:
                coords.append(
                    {
                        "x": lm.x,
                        "y": lm.y,
                        "z": getattr(lm, "z", 0.0),
                        "visibility": getattr(lm, "visibility", 0.0),
                    }
                )
                xs.append(lm.x)
                ys.append(lm.y)
                confidence_values.append(getattr(lm, "visibility", 0.0))
            bbox = {
                "x_min": max(0.0, min(xs) if xs else 0.0),
                "x_max": min(1.0, max(xs) if xs else 0.0),
                "y_min": max(0.0, min(ys) if ys else 0.0),
                "y_max": min(1.0, max(ys) if ys else 0.0),
            }
            poses.append(
                {
                    "pose_id": int(idx),
                    "confidence": float(np.mean(confidence_values) if confidence_values else 0.0),
                    "landmarks": coords,
                    "bbox": bbox,
                    "tracking_id": int(result.pose_tracking_ids[idx]) if hasattr(result, "pose_tracking_ids") else idx,
                }
            )
        return PoseResult(poses=poses, width=frame.shape[1], height=frame.shape[0])

    async def _detect_with_legacy(self, frame: np.ndarray) -> PoseResult:
        async with self._legacy_lock:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._legacy_detect_sync, frame)

    def _legacy_detect_sync(self, frame: np.ndarray) -> PoseResult:
        rgb = frame
        results = self._legacy_pose.process(rgb)
        poses = []
        if results.pose_landmarks:
            coords = []
            xs, ys = [], []
            confidence_values = []
            for lm in results.pose_landmarks.landmark:
                coords.append(
                    {
                        "x": lm.x,
                        "y": lm.y,
                        "z": getattr(lm, "z", 0.0),
                        "visibility": getattr(lm, "visibility", 0.0),
                    }
                )
                xs.append(lm.x)
                ys.append(lm.y)
                confidence_values.append(getattr(lm, "visibility", 0.0))
            bbox = {
                "x_min": max(0.0, min(xs) if xs else 0.0),
                "x_max": min(1.0, max(xs) if xs else 0.0),
                "y_min": max(0.0, min(ys) if ys else 0.0),
                "y_max": min(1.0, max(ys) if ys else 0.0),
            }
            poses.append(
                {
                    "pose_id": 0,
                    "confidence": float(np.mean(confidence_values) if confidence_values else 0.0),
                    "landmarks": coords,
                    "bbox": bbox,
                    "tracking_id": 0,
                }
            )
        return PoseResult(poses=poses, width=frame.shape[1], height=frame.shape[0])


class OneEuroFilter:
    def __init__(self, min_cutoff: float = 1.2, beta: float = 0.01, d_cutoff: float = 1.0) -> None:
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        self.x_prev = None
        self.dx_prev = 0.0
        self.t_prev = None

    def __call__(self, value: float, timestamp: float) -> float:
        if self.t_prev is None:
            self.t_prev = timestamp
            self.x_prev = value
            return value

        dt = max(1e-3, timestamp - self.t_prev)
        dx = (value - self.x_prev) / dt
        alpha_d = self._alpha(self.d_cutoff, dt)
        dx_hat = alpha_d * dx + (1 - alpha_d) * self.dx_prev

        cutoff = self.min_cutoff + self.beta * abs(dx_hat)
        alpha = self._alpha(cutoff, dt)
        x_hat = alpha * value + (1 - alpha) * self.x_prev

        self.x_prev = x_hat
        self.dx_prev = dx_hat
        self.t_prev = timestamp
        return x_hat

    @staticmethod
    def _alpha(cutoff: float, dt: float) -> float:
        tau = 1.0 / (2 * np.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)


class PoseSmoother:
    def __init__(self) -> None:
        self.filters: Dict[int, Dict[int, Tuple[OneEuroFilter, OneEuroFilter, OneEuroFilter]]] = {}

    def smooth(self, track_id: int, landmarks: List[Dict[str, float]], timestamp: float) -> List[Dict[str, float]]:
        pose_id = int(track_id)
        if pose_id not in self.filters:
            self.filters[pose_id] = {}

        smoothed = []
        for idx, lm in enumerate(landmarks):
            if idx not in self.filters[pose_id]:
                self.filters[pose_id][idx] = (
                    OneEuroFilter(),
                    OneEuroFilter(),
                    OneEuroFilter(min_cutoff=1.6),
                )
            fx, fy, fz = self.filters[pose_id][idx]
            smoothed.append(
                {
                    "x": fx(lm["x"], timestamp),
                    "y": fy(lm["y"], timestamp),
                    "z": fz(lm.get("z", 0.0), timestamp),
                    "visibility": lm.get("visibility", 0.0),
                }
            )
        return smoothed

    def drop_pose(self, pose_id: int) -> None:
        self.filters.pop(pose_id, None)


class PoseTrack:
    def __init__(self, track_id: int, centroid: Tuple[float, float], timestamp: float, confidence: float) -> None:
        self.track_id = track_id
        self.centroid = centroid
        self.confidence = confidence
        self.last_timestamp = timestamp
        self.missed = 0

    def update(self, centroid: Tuple[float, float], timestamp: float, confidence: float) -> None:
        self.centroid = centroid
        self.confidence = confidence
        self.last_timestamp = timestamp
        self.missed = 0


class PoseTrackManager:
    def __init__(self, max_distance: float = 0.18, max_missing: int = 6) -> None:
        self.max_distance = max_distance
        self.max_missing = max_missing
        self.tracks: Dict[int, PoseTrack] = {}
        self.next_track_id = 1

    def update(self, poses: List[Dict[str, Any]], timestamp: float) -> Tuple[List[Dict[str, Any]], List[int]]:
        # Age existing tracks each frame; matched detections reset the counter
        for track in self.tracks.values():
            track.missed += 1

        if not poses:
            removed_only = self._cleanup_tracks()
            return [], removed_only

        centroids = [
            (
                float(np.mean([lm['x'] for lm in pose['landmarks']])),
                float(np.mean([lm['y'] for lm in pose['landmarks']])),
            )
            for pose in poses
        ]
        assigned_tracks: Dict[int, int] = {}

        track_ids = list(self.tracks.keys())
        if track_ids:
            cost_matrix = np.full((len(track_ids), len(centroids)), np.inf, dtype=float)
            for i, track_id in enumerate(track_ids):
                track = self.tracks[track_id]
                for j, centroid in enumerate(centroids):
                    dist = np.linalg.norm(np.array(track.centroid) - np.array(centroid))
                    cost_matrix[i, j] = dist

            used_cols = set()
            while True:
                min_val = cost_matrix.min(initial=np.inf)
                if not np.isfinite(min_val) or min_val > self.max_distance:
                    break
                rows, cols = np.where(cost_matrix == min_val)
                row_idx, col_idx = int(rows[0]), int(cols[0])
                if col_idx in used_cols:
                    cost_matrix[row_idx, col_idx] = np.inf
                    continue
                assigned_tracks[track_ids[row_idx]] = col_idx
                used_cols.add(col_idx)
                cost_matrix[row_idx, :] = np.inf
                cost_matrix[:, col_idx] = np.inf

        tracked_poses: List[Dict[str, Any]] = []
        matched_columns = set()
        for track_id, detection_idx in assigned_tracks.items():
            pose = poses[detection_idx]
            centroid = centroids[detection_idx]
            confidence = pose.get('confidence', 0.0)
            track = self.tracks[track_id]
            track.update(centroid, timestamp, confidence)
            track.missed = 0
            pose['track_id'] = track.track_id
            tracked_poses.append(pose)
            matched_columns.add(detection_idx)

        for idx, pose in enumerate(poses):
            if idx in matched_columns:
                continue
            centroid = centroids[idx]
            confidence = pose.get('confidence', 0.0)
            track_id = self.next_track_id
            self.next_track_id += 1
            self.tracks[track_id] = PoseTrack(track_id, centroid, timestamp, confidence)
            pose['track_id'] = track_id
            tracked_poses.append(pose)

        removed = self._cleanup_tracks()
        return tracked_poses, removed

    def _cleanup_tracks(self) -> List[int]:
        expired = [track_id for track_id, track in self.tracks.items() if track.missed > self.max_missing]
        for track_id in expired:
            self.tracks.pop(track_id, None)
        return expired


class PoseStreamSession:
    def __init__(self, websocket: WebSocket, engine: PoseEngine) -> None:
        self.ws = websocket
        self.engine = engine
        self.smoother = PoseSmoother()
        self.tracker = PoseTrackManager()
        self.running = True
        self.event_sink = os.environ.get('POSE_EVENT_ENDPOINT')
        self._http_client = None

    async def _emit_event(self, payload: Dict[str, Any]) -> None:
        if not self.event_sink or httpx is None:
            return
        try:
            if self._http_client is None:
                self._http_client = httpx.AsyncClient(timeout=2.0)
            await self._http_client.post(self.event_sink, json=payload)
        except Exception:
            logger = getattr(self, 'logger', None)
            if logger:
                logger.debug('pose event emit failed', exc_info=True)

    async def run(self) -> None:
        while self.running:
            message = await self.ws.receive()
            if message["type"] == "websocket.disconnect":
                break

            if "text" in message and message["text"] is not None:
                payload = await self._handle_text_message(message["text"])
                if payload is not None:
                    await self.ws.send_json(payload)
            elif "bytes" in message and message["bytes"] is not None:
                await self.ws.send_json({"type": "error", "code": "binary_not_supported"})

    async def _handle_text_message(self, text: str) -> Optional[Dict[str, Any]]:
        try:
            data = json.loads(text)
        except Exception:
            return {"type": "error", "code": "invalid_json"}

        if data.get("type") == "ping":
            return {"type": "pong", "ts": int(time.time() * 1000)}

        if data.get("type") != "frame":
            return {"type": "error", "code": "unsupported_message"}

        image_base64 = data.get("image_base64")
        if not image_base64:
            return {"type": "error", "code": "missing_image"}

        frame_bytes = base64.b64decode(image_base64.split(",")[-1])
        frame = to_rgb_array(frame_bytes)
        timestamp_ms = data.get("timestamp_ms") or int(time.time() * 1000)

        result = await self.engine.detect(frame, timestamp_ms=timestamp_ms)
        ts_seconds = timestamp_ms / 1000.0
        smoothed_poses = []
        tracked_poses, removed_tracks = self.tracker.update(result.poses, ts_seconds)
        for track_id in removed_tracks:
            self.smoother.drop_pose(track_id)
        for pose in tracked_poses:
            track_id = pose.get("track_id", pose.get("tracking_id", pose.get("pose_id", 0)))
            smoothed_landmarks = self.smoother.smooth(track_id, pose["landmarks"], ts_seconds)
            smoothed_poses.append(
                {
                    **pose,
                    "landmarks": smoothed_landmarks,
                }
            )

        response = {
            "type": "pose",
            "frame": data.get("frame"),
            "timestamp_ms": timestamp_ms,
            "poses": smoothed_poses,
            "meta": {
                "width": result.width,
                "height": result.height,
                "mode": self.engine.mode,
            },
        }
        if self.event_sink:
            asyncio.create_task(self._emit_event(response))
        return response

    async def close(self, code: int, reason: str) -> None:
        self.running = False
        await self.ws.close(code=code, reason=reason)
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
