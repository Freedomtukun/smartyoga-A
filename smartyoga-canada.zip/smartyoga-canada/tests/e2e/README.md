# E2E Tests

Add Playwright or Detox scenarios validating camera flow and billing checkout.
