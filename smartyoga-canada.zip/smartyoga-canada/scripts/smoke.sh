#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8000}
echo "== Health =="
curl -sS "$BASE/healthz" | jq '.'

echo "== Register demo user =="
curl -sS -X POST "$BASE/auth/register" \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@example.ca","password":"DemoPass123","display_name":"Demo","locale":"en-CA"}' | jq '.'

echo "== Login demo user =="
TOKEN=$(curl -sS -X POST "$BASE/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@example.ca","password":"DemoPass123"}' | jq -r '.access_token')

echo "== Create session =="
SESSION=$(curl -sS -X POST "$BASE/sessions" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"device_id":"dev_cli","pose_profile":"vinyasa-basic","notes":"Smoke","app_version":"1.0.0"}' | jq -r '.session_id')

echo "== Submit frame =="
curl -sS -X POST "$BASE/sessions/$SESSION/frames" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"frame_id":"cli_frame","timestamp_ms":0,"pose_landmarks":[{"name":"LEFT_ELBOW","x":0.4,"y":0.2,"z":0.0,"visibility":0.98}]}' | jq '.'

echo "== Request TTS =="
curl -sS -X POST "$BASE/tts/speak" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"text":"Keep your back straight","voice_id":"en_CA_female_1"}' | jq '.'
