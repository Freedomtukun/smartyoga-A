# Latency Baseline (Placeholder)

| Service | Median Latency (ms) | Notes |
|---------|---------------------|-------|
| Pose    | 85                  | MediaPipe Tasks on M1 Mac |
| TTS     | 400                 | Piper en-CA female voice |
