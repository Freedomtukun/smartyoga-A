# Acceptance Checklist

## M0 技术基线
- [ ] `docker compose up --build` 启动 api/pose/tts/db/cache/nginx
- [ ] `GET /healthz` 返回 200 并包含 `uptime_s`
- [ ] Piper 与 MediaPipe 延迟记录提交至 `docs/metrics/baseline.md`

## M1 前端 Alpha
- [ ] React Native 客户端可启动并自动创建会话
- [ ] UI 仅显示 Score + Advice + Summary
- [ ] 离线状态缓存最近一次评分
- [ ] 语音按钮调用本地 TTS mock 成功

## M2 后端 Beta
- [ ] Auth / Session / Billing API 集成测试通过
- [ ] Stripe Checkout 测试卡流程成功
- [ ] `/sessions/{id}` 可返回历史评分列表

## M3 语音 & 同步
- [ ] Piper 本地播报成功且延迟 < 1.5s
- [ ] 网络断开自动切换 Coqui fallback
- [ ] 语音缓存可在离线播放

## M4 合规上线
- [ ] 完成 PIPEDA DPIA 文档
- [ ] 日志脱敏策略在 prod 配置生效
- [ ] Nginx + TLS smoke 测试通过
- [ ] App 发布包满足审核清单
