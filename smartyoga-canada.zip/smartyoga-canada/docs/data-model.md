# Data Model Overview

```
users (uuid)
  - email (unique)
  - password_hash
  - display_name
  - locale
  - membership_tier
  - stripe_customer_id
  - created_at / updated_at

auth_tokens (uuid)
  - user_id (fk users)
  - refresh_token_hash
  - expires_at

sessions (uuid)
  - user_id (fk users)
  - pose_profile
  - notes
  - started_at / ended_at
  - status
  - avg_score
  - summary

pose_frames (uuid)
  - session_id (fk sessions)
  - frame_id
  - timestamp_ms
  - score
  - advice (jsonb)
  - summary
  - confidence
  - raw_landmarks (jsonb)
  - media_path

voice_feedback (uuid)
  - session_id
  - frame_id
  - engine
  - audio_url
  - duration_ms

memberships (uuid)
  - user_id
  - stripe_subscription_id
  - status
  - current_period_end
  - plan_id

analytics_events (uuid)
  - user_id
  - session_id
  - event_name
  - emitted_at
  - payload (jsonb)

audit_logs (uuid)
  - actor_id
  - action
  - target_type
  - target_id
  - metadata (jsonb)
  - created_at
```
