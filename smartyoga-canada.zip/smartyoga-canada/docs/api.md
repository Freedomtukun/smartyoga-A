# SmartYoga API Draft

Base URL: `https://api.smartyoga.ca`

## Authentication
JWT bearer tokens. Obtain via `/auth/register` or `/auth/login`. Refresh using `/auth/token/refresh`.

## Error Format
```json
{
  "error_code": "E1006",
  "message": "Unauthorized",
  "detail": {"hint": "Bearer token missing"}
}
```

## Health
### `GET /healthz`
- 200 OK `HealthStatus`.

## Auth
### `POST /auth/register`
- Request `RegisterRequest`
- Response 201 `AuthResponse`
- Errors: E1000, E1004

### `POST /auth/login`
- Request `LoginRequest`
- Response 200 `AuthResponse`
- Errors: E1001, E1005

### `POST /auth/token/refresh`
- Request `TokenRefreshRequest`
- Response 200 `AuthResponse`
- Errors: E1002, E1003

## Users
### `GET /users/me`
- Response `UserProfile`
- Errors: E1006, E1007

### `PATCH /users/me`
- Request `UserUpdateRequest`
- Response `UserProfile`

## Sessions
### `POST /sessions`
- Request `SessionCreateRequest`
- Response 201 `SessionSummary`
- Errors: E2002

### `GET /sessions/{session_id}`
- Response `SessionDetail`

### `POST /sessions/{session_id}/frames`
- Request `PoseFramePayload`
- Response `PoseInferenceResult`
- Errors: E2000, E2001

## TTS
### `POST /tts/speak`
- Request `TTSRequest`
- Response `TTSResponse`
- Errors: E2100, E2101

## Billing
### `POST /billing/checkout`
- Request `CheckoutRequest`
- Response `CheckoutSession`

### `POST /billing/webhook`
- Request `StripeWebhookEvent`
- Response `WebhookAck`

### `GET /billing/subscription`
- Response `SubscriptionStatus`

## Analytics
### `POST /analytics/events`
- Request `AnalyticsEvent`
- Response `AnalyticsAccepted`

## Admin
### `GET /admin/system-metrics`
- Response `SystemMetrics`

## AI
### `POST /ai/chat`
- Request `AIChatRequest`
- Response `AIChatResponse`
- Description: Conversational endpoint backed by Grok with tool calls for guide/pose/places/support.
- Body fields:
  - `messages` – Array of `{role, content}` in chronological order.
  - `persona` – Optional persona id (e.g. `nova`, `aurora`, `mingxia`).
  - `locale` – Optional locale hint (`en-CA`, `fr-CA`, `zh-CN`).
  - `context` – Optional object with `memorySummary`, `goal`, etc.

## Memory
### `GET /memory/{userId}`
- Returns the user's memory profile, summary, and last entry preview.

### `PATCH /memory/{userId}`
- Upserts profile/preferences/summary fields on the memory document.

### `GET /memory/{userId}/entries`
- Lists memory entry history; supports `limit` and `order` query params.

### `POST /memory/{userId}/entries`
- Appends a new memory entry (`type`, `content`, optional `summary`, `tags`).

## Realtime
- WebSocket endpoint: `ws://<host>:8080/realtime`
- Handshake: send `{"type":"hello","userId":"usr_xxx","persona":"nova","locale":"en-CA"}`.
- Audio flow: binary PCM chunks, followed by `{"type":"audio.commit"}` to trigger STT.
- Text flow: send `{"type":"user.text","text":"Let's begin"}` for immediate Grok reply.
- Server messages: `ready`, `ack`, `transcript`, `assistant.reply`, error codes.

## Schemas
- `HealthStatus`
- `RegisterRequest`
- `LoginRequest`
- `TokenRefreshRequest`
- `AuthResponse`
- `UserProfile`
- `UserUpdateRequest`
- `SessionCreateRequest`
- `SessionSummary`
- `SessionDetail`
- `PoseFramePreview`
- `PoseFramePayload`
- `PoseLandmark`
- `PoseInferenceResult`
- `TTSRequest`
- `TTSResponse`
- `CheckoutRequest`
- `CheckoutSession`
- `StripeWebhookEvent`
- `WebhookAck`
- `SubscriptionStatus`
- `AnalyticsEvent`
- `AnalyticsAccepted`
- `SystemMetrics`
- `ErrorResponse`
- `AIChatRequest`
- `AIChatResponse`

See `services/api/app/models` for JSON examples.
