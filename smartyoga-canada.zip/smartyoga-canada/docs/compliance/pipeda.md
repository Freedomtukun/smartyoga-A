# PIPEDA Readiness Checklist

- Consent: explicit opt-in during registration with localized copy (en-CA/fr-CA).
- Accountability: designate DPO; record in `docs/compliance/dpo.md`.
- Limiting Collection: collect only email, display name, locale, pose metrics.
- Limiting Use/Disclosure: restrict session data to coaching and analytics.
- Safeguards: TLS everywhere, encrypted Postgres at rest, S3/GCS bucket with CMEK.
- Openness: publish privacy policy in mobile app and website.
- Individual Access: `/users/me` returns all stored personal data.
- Challenging Compliance: support email `privacy@smartyoga.ca` triaged within 30 days.
- Retention: background job deletes inactive sessions after `PIPEDA_RETENTION_DAYS`.
- Audit: log accesses into `audit_logs` table; review quarterly.
