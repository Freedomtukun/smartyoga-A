# Data Protection Officer

- Name: TBD
- Email: privacy@smartyoga.ca
- Phone: +1-555-0100
- Responsibilities: Oversees PIPEDA compliance, handles SARs, coordinates breach notifications.
