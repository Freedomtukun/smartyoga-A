# Architecture Overview

## High-Level Flow
1. React Native app captures camera frames and streams pose landmarks to the local pose microservice (`services/pose`).
2. Pose microservice runs MediaPipe Tasks to produce `score`, `advice`, and `summary`, returning results directly to the app. Results are cached locally via Zustand.
3. Mobile app syncs completed session snapshots to FastAPI backend when connectivity is available. The backend persists sessions to Postgres and queues analytics in Redis.
4. FastAPI orchestrates Stripe Checkout/Billing, issues JWT-based auth tokens, and exposes the API consumed by mobile clients.
5. TTS microservice hosts Piper voice models. The app uses local Piper when reachable; otherwise it calls FastAPI `/tts/speak` which proxies to remote Coqui fallback.

## Services
- **Mobile (React Native + Expo)**: TypeScript, Zustand. Runs local mode by default using `POSE_SERVICE_URL` pointing to local LAN IP.
- **API (FastAPI)**: Python 3.11, Pydantic v2, Async SQLAlchemy. Provides auth, session management, billing, analytics.
- **Pose (FastAPI)**: wraps MediaPipe Tasks Python API, exposes `/v1/pose/infer` and `/healthz`.
- **TTS (FastAPI)**: wraps Piper CLI with caching; fallback to Coqui Cloud via API key.
- **Infra**: Dockerized microservices orchestrated via `docker-compose`; target deployment on GKE with Nginx reverse proxy.

## Data Flow & Storage
- Primary data store: Postgres for users, sessions, memberships.
- Redis for auth session caching and analytics queue.
- Google Cloud Storage bucket for media assets and generated audio.
- Audit logs stored in Postgres `audit_logs` table for PIPEDA compliance.

## Security & Compliance
- OAuth password flow with hashed refresh tokens.
- Stripe webhooks validated with signing secret.
- PIPEDA baseline: minimum data collection, retention policy enforced via background job (see `services/api/app/jobs/retention.py`).
- TLS termination handled by Nginx Ingress in production.

## Local Development
- `docker compose up --build` runs API, pose, tts, Postgres, Redis, and Nginx.
- React Native app uses Metro bundler; configure `.env` to target `http://localhost:8080` proxied through Nginx.
- Contract tests located in `tests/e2e/` validate API against pose/tts mocks.
